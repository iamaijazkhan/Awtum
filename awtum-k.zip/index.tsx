import React, { useState, useEffect, useRef } from "react";
import { createRoot } from "react-dom/client";
import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { marked } from "marked";

const API_KEY = process.env.API_KEY;

// --- ICONS ---
const UpdateIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
  >
    <path d="M16 2H8C4.691 2 2 4.691 2 8v8c0 3.309 2.691 6 6 6h8c3.309 0 6-2.691 6-6V8c0-3.309-2.691-6-6-6zm4 14c0 2.206-1.794 4-4 4H8c-2.206 0-4-1.794-4-4V8c0-2.206 1.794-4 4-4h8c2.206 0 4 1.794 4 4v8z" />
    <path d="M11 7h2v4h4v2h-4v4h-2v-4H7v-2h4V7z" />
  </svg>
);
const TranslateIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
  >
    <path d="M21.928 11.607c-.117-.393-.341-.754-.641-1.053L16.29 5.559a1.002 1.002 0 0 0-1.593 1.202l1.531 2.041H11.5c-2.481 0-4.5 2.019-4.5 4.5s2.019 4.5 4.5 4.5h1.999l-1.531 2.041a1 1 0 0 0 1.593 1.202l4.997-4.997c.3-.3.523-.66.641-1.053.118-.393.172-.813.172-1.247s-.054-.854-.172-1.247zM10.5 13.25c-.413 0-.75.337-.75.75s.337.75.75.75h1v-1.5h-1z" />
    <path d="m10.25 10.75-.625-1.5-1.25-3L7.75 5h-1.5l-3 8h1.5l.625-1.5h2.75l.625 1.5z" />
  </svg>
);
const StringsIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
  >
    <path d="M8.646 4.646 3.793 9.5l4.853 4.854 1.414-1.414L6.414 10.5l3.646-3.646zm6.708 1.414L11.707 9.5l3.647 3.646-3.647 3.646 1.414 1.414 4.854-4.853-4.854-4.853z" />
  </svg>
);
const PavaIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
  >
    <path d="M12 2C6.486 2 2 6.486 2 12s4.486 10 10 10 10-4.486 10-10S17.514 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8z" />
    <path d="m11 15.586-3.293-3.293-1.414 1.414L11 18.414l6.707-6.707-1.414-1.414z" />
  </svg>
);
const GeminiIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
  >
    <path d="M20.25 4.5a2.25 2.25 0 0 0-2.25-2.25H6a2.25 2.25 0 0 0-2.25 2.25v15a2.25 2.25 0 0 0 2.25 2.25h12a2.25 2.25 0 0 0 2.25-2.25ZM8.25 15h7.5V13.5h-7.5Zm0-3h7.5V10.5h-7.5Zm0-3h7.5V7.5h-7.5Z" />
  </svg>
);
const SendIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" width="24px" height="24px">
        <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
    </svg>
);
const MoonIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
    </svg>
);
const SunIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="5"></circle>
        <line x1="12" y1="1" x2="12" y2="3"></line>
        <line x1="12" y1="21" x2="12" y2="23"></line>
        <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
        <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
        <line x1="1" y1="12" x2="3" y2="12"></line>
        <line x1="21" y1="12" x2="23" y2="12"></line>
        <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
        <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
    </svg>
);
const CollapseIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="20px" height="20px">
        <path d="M15.293 3.293 6.586 12l8.707 8.707 1.414-1.414L9.414 12l7.293-7.293z"/>
    </svg>
);
const ExpandIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="20px" height="20px">
        <path d="M9.707 19.707 18.414 11l-8.707-8.707-1.414 1.414L15.586 11l-7.293 7.293z"/>
    </svg>
);
const AddFileIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24px" height="24px">
        <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
    </svg>
);
const CloseIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="20px" height="20px">
        <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
    </svg>
);
const TrashIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="18px" height="18px">
        <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
    </svg>
);
const NewChatIcon = () => (
     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
        <path d="M19 11h-6V5h-2v6H5v2h6v6h2v-6h6z"/>
    </svg>
);
const CopyIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" viewBox="0 0 24 24" fill="currentColor">
        <path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>
    </svg>
);
const CheckIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" viewBox="0 0 24 24" fill="currentColor">
        <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
    </svg>
);
const PencilIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="16px" height="16px">
        <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a.9959.9959 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
    </svg>
);
const DocumentIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24px" height="24px">
        <path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zM16 18H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/>
    </svg>
);
const RefreshIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="20px" height="20px">
        <path d="M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"/>
    </svg>
);

// --- API INITIALIZATION ---
const ai = new GoogleGenAI({ apiKey: API_KEY });

// --- HELPER FUNCTIONS ---
const fileToPart = async (file: File) => {
    const base64Data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.onerror = error => reject(error);
    });
    return { inlineData: { mimeType: file.type, data: base64Data } };
};


// --- HELPER COMPONENTS ---
const LoadingComponent = () => (
    <div className="loading-container">
        <div className="spinner"></div>
        <span>Thinking...</span>
    </div>
);

type CopyButtonProps = {
    textToCopy: string;
};
const CopyButton = ({ textToCopy }: CopyButtonProps) => {
    const [isCopied, setIsCopied] = useState(false);

    const handleCopy = async () => {
        if (isCopied) return;
        try {
            await navigator.clipboard.writeText(textToCopy);
            setIsCopied(true);
            setTimeout(() => setIsCopied(false), 2000);
        } catch (err) {
            console.error("Failed to copy text: ", err);
        }
    };

    return (
        <button onClick={handleCopy} className={`copy-button ${isCopied ? 'copied' : ''}`} aria-label={isCopied ? "Copied" : "Copy to clipboard"}>
            {isCopied ? <CheckIcon /> : <CopyIcon />}
            <span>{isCopied ? "Copied" : "Copy"}</span>
        </button>
    );
};

// --- Reusable File Input Component ---
type FileInputProps = {
    file: File | null;
    onFileChange: (file: File | null) => void;
    label: string;
};

const FileInputComponent = ({ file, onFileChange, label }: FileInputProps) => {
    const fileInputRef = useRef<HTMLInputElement>(null);
    const acceptTypes = ".pdf,.doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            onFileChange(e.target.files[0]);
        }
    };

    const handleRemoveFile = (e: React.MouseEvent) => {
        e.stopPropagation();
        onFileChange(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            onFileChange(e.dataTransfer.files[0]);
        }
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
    };

    return (
        <div className="file-input-wrapper">
            {label && <label>{label}</label>}
            <div
                className="file-drop-zone"
                onClick={() => fileInputRef.current?.click()}
                onDrop={handleDrop}
                onDragOver={handleDragOver}
            >
                <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    style={{ display: 'none' }}
                    accept={acceptTypes}
                />
                {file ? (
                    <div className="file-display">
                        <DocumentIcon />
                        <span className="file-display-name">{file.name}</span>
                        <button onClick={handleRemoveFile} className="remove-file-button" aria-label="Remove file">
                            <CloseIcon />
                        </button>
                    </div>
                ) : (
                    <span>Click or drag & drop file here</span>
                )}
            </div>
        </div>
    );
};


// --- SECTION VIEWS ---
const TABS = [
    "Understanding",
    "File History",
    "Priority Document Analyzer",
    "Complaint Document Analyzer",
    "IPR Analyzer",
    "Generate Email"
];

const FirstUpdateView = () => {
    const [activeTab, setActiveTab] = useState(TABS[0]);
    
    // State for all inputs
    const [understandingFile, setUnderstandingFile] = useState<File | null>(null);
    const [understandingResult, setUnderstandingResult] = useState("");
    const [fileHistoryFiles, setFileHistoryFiles] = useState<File[]>([]);
    const [fileHistoryResult, setFileHistoryResult] = useState("");
    const [priorityClaimText, setPriorityClaimText] = useState("");
    const [priorityDoc, setPriorityDoc] = useState<File | null>(null);
    const [priorityDocResult, setPriorityDocResult] = useState("");
    const [complaintPatentNumber, setComplaintPatentNumber] = useState("");
    const [complaintDoc, setComplaintDoc] = useState<File | null>(null);
    const [complaintDocResult, setComplaintDocResult] = useState("");
    const [iprPatentNumber, setIprPatentNumber] = useState("");
    const [iprDoc, setIprDoc] = useState<File | null>(null);
    const [iprDocResult, setIprDocResult] = useState("");
    const [emailResult, setEmailResult] = useState("");
    const [emailInputResults, setEmailInputResults] = useState("");
    const [emailExtraInput, setEmailExtraInput] = useState("");

    // Loading and Error states
    const [isUnderstandingLoading, setIsUnderstandingLoading] = useState(false);
    const [isFileHistoryLoading, setIsFileHistoryLoading] = useState(false);
    const [isPriorityDocLoading, setIsPriorityDocLoading] = useState(false);
    const [isComplaintDocLoading, setIsComplaintDocLoading] = useState(false);
    const [isIprDocLoading, setIsIprDocLoading] = useState(false);
    const [isEmailLoading, setIsEmailLoading] = useState(false);
    const [error, setError] = useState("");

    const fileHistoryInputRef = useRef<HTMLInputElement>(null);

    const handleClearAll = () => {
        if (window.confirm("Are you sure?")) {
            setActiveTab(TABS[0]);
            setUnderstandingFile(null);
            setUnderstandingResult("");
            setFileHistoryFiles([]);
            setFileHistoryResult("");
            setPriorityClaimText("");
            setPriorityDoc(null);
            setPriorityDocResult("");
            setComplaintPatentNumber("");
            setComplaintDoc(null);
            setComplaintDocResult("");
            setIprPatentNumber("");
            setIprDoc(null);
            setIprDocResult("");
            setEmailResult("");
            setEmailInputResults("");
            setEmailExtraInput("");
            setError("");
        }
    };
    
    const handleFileHistoryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            setFileHistoryFiles(prev => [...prev, ...Array.from(e.target.files)]);
        }
    };
    
    const handleRemoveFileHistoryFile = (indexToRemove: number) => {
        setFileHistoryFiles(prev => prev.filter((_, index) => index !== indexToRemove));
    };
    
    const handleFileHistoryDrop = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            setFileHistoryFiles(prev => [...prev, ...Array.from(e.dataTransfer.files)]);
        }
    };
    
    const handleFileHistoryDragOver = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
    };

    const handleGenerateUnderstanding = async () => {
         if (!understandingFile) {
            setError("Please upload a patent document.");
            return;
        }
        setIsUnderstandingLoading(true);
        setError("");
        setUnderstandingResult("");

        try {
            const prompt = `You are an expert patent analyst. Your task is to analyze the provided patent document and generate a structured summary.

**Instructions:**
1.  **Find Patent Number:** Your first step is crucial. Carefully examine the document, especially the top of the first page, to find the patent number. It could be in various formats (e.g., USXXXXXXXB2, EPXXXXXXXB1, WOXXXXXXXXXXA1). Use the *exact* number you find. If you cannot find a clear patent number, begin the overview with "[Patent number not found] (hereinafter referred to as ‘subject patent’) discloses...".
2.  **Strictly Follow Template & Rules:** Adhere to the structure, headings, word counts, and tone of the example template provided below.
3.  **No Forbidden Phrases:** Do not use the terms "claim 1" or "background" anywhere in your generated text, except for the single, specific phrase "as outlined in the claim 1 below:" in the solution's introduction.
4.  **Content Requirements:**
    *   **Overview:** This section should be based on the patent's claim 1. It must be a single paragraph of around 100 words. It must start with the patent number you found, like this: "USXXXXX (hereinafter referred to as ‘subject patent’) discloses...".
    *   **In depth Concept - Problem:** This subsection should be based on the patent's background section. It must be around 100 words.
    *   **In depth Concept - Solution:** This subsection must be based on the features of claim 1, following the same flow and order. It can use bullet points. It must be around 400 words.
5.  **Output Format:** The entire output must be in markdown. The headings (Overview, In depth Concept, Problem, Solution) should not be bolded.

---
**EXAMPLE TEMPLATE:**

Overview:
US10103845B2 (hereinafter referred to as ‘subject patent’) discloses a smart Wi-Fi system called the BES System. It helps routers and devices like laptops send and receive data faster in two ways: using multiple antennas to send different data streams at once on the same frequency (MODE-1: Spatial Multiplexing) or using different frequencies to send more data (MODE-2: Expanded Bandwidth). The system can use both modes together for maximum throughput and uses the same hardware for both modes. It dynamically switches or combines modes based on signal quality, optimizing high-speed data transfer for streaming and downloads.

In depth Concept:

Problem:
Wireless communication systems, particularly those using Orthogonal Frequency Division Multiplexing (OFDM) for Wi-Fi (e.g., IEEE 802.11 standards), face increasing consumer demand for higher data rates to support applications like video streaming and large file transfers. Traditional single-input, single-output (SISO) systems are limited, sending only one data stream on a single frequency channel (e.g., 20 MHz), which restricts speed. Meeting IEEE 802.11n’s high data rate requirements is challenging due to interference when using multiple data streams, limited frequency availability, and the need for cost-effective solutions. Manufacturers require a system that boosts data rates without expensive, specialized hardware.

Solution:
The patent addresses this problem by introducing the Bandwidth Expansion and Spatial Multiplexing (BES) System which provides a dual-mode solution, enabling high data rates through flexible operation using the same hardware, as outlined in the claim 1 below:
• Configuring a transceiver: The transceiver includes first and second transmitters, each connected to respective antenna sets, to operate in two modes: spatial multiplexing and combined spatial multiplexing with bandwidth expansion.
• Operating in first mode (spatial multiplexing): The transceiver processes data using multiple antennas on a single frequency spectrum.
o Generating first mode transmit symbols: The first and second transmitters create separate transmit symbols (data packets formatted for transmission, e.g., for OFDM) from incoming data.
o Transmitting on same frequency spectrum: These symbols are sent via the first and second antenna sets across the same frequency spectrum (e.g., a 20 MHz channel).
• Operating in second mode (spatial multiplexing and bandwidth expansion): The transceiver uses multiple frequency spectrums for data transmission.
o Generating second mode transmit symbols: The first and second transmitters generate separate transmit symbols from incoming data.
o Transmitting on first frequency spectrum: The first transmitters send their symbols via the first antenna set across a first frequency spectrum (e.g., 20 MHz at frequency F1).
o Transmitting on second frequency spectrum: The second transmitters send their symbols via the second antenna set across a second frequency spectrum (e.g., 20 MHz at F2), where the first and second spectrums do not overlap.

---
NOW, ANALYZE THE DOCUMENT YOU ARE GIVEN AND GENERATE THE OUTPUT FOLLOWING ALL INSTRUCTIONS.`;
            const promptParts: any[] = [{ text: prompt }];

            promptParts.push(await fileToPart(understandingFile));

            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash-preview-04-17",
                contents: { parts: promptParts },
            });
            setUnderstandingResult(response.text);

        } catch (err) {
            setError(err instanceof Error ? err.message : "An unknown error occurred.");
        } finally {
            setIsUnderstandingLoading(false);
        }
    };
    
    const handleGenerateFileHistoryAnalysis = async () => {
        if (fileHistoryFiles.length === 0) {
            setError("Please attach at least one file history document.");
            return;
        }
        setIsFileHistoryLoading(true);
        setError("");
        setFileHistoryResult("");

        try {
            const prompt = `You are an expert patent analyst specializing in summarizing patent prosecution histories. Your task is to analyze the provided file history document(s) and generate a detailed, structured summary focusing exclusively on the evolution of **Claim 1**.

**Instructions:**
1.  **Focus on Claim 1:** Your entire analysis must track the lifecycle of Claim 1, from its initial filing to its final allowance.
2.  **Identify Documents:** List all prior art documents (D1, D2, etc.) that were cited by the examiner to reject Claim 1.
3.  **Follow the Timeline for Claim 1:** Present the events chronologically. Start with the initial Claim 1, followed by each rejection that applies to it, the applicant's arguments regarding Claim 1, and any amendments made specifically to Claim 1. Repeat this cycle for all relevant office actions.
4.  **Be Specific:** In the rejection sections, clearly state how the cited art was applied to the limitations of Claim 1. In the response sections, summarize the applicant's arguments defending the novelty and non-obviousness of Claim 1. In the amendment sections, clearly show the exact changes made to the text of Claim 1.
5.  **Adhere Strictly to the Template:** Your output MUST follow the exact format and headings provided in the template below. Use markdown for formatting.
6.  **Internal Verification Process for Highest Accuracy:** Before producing the final output, you must internally follow a three-step process. This is for your own thinking process and should not be part of the final output.
    *   **Step 1 (Extract):** Read through all provided documents and extract every piece of information relevant to Claim 1's evolution (initial text, rejections, prior art, responses, amendments, final text).
    *   **Step 2 (Structure):** Organize all the extracted information chronologically into the required OUTPUT TEMPLATE format.
    *   **Step 3 (Verify & Refine - The Final Loop):** Critically review your structured output from Step 2. Compare it one last time against the source documents to verify every detail. Correct any inaccuracies, ensure all rejections are correctly mapped to responses and amendments, and confirm the final text is perfect. Only after this final verification loop should you provide the output.

---
**OUTPUT TEMPLATE:**

We have gone through the prosecution history of the subject patent and found that the examiner had raised rejections on Claim 1 on the basis of following documents:
D1: [Full citation of Document 1]
D2: [Full citation of Document 2]
....

**[Initial Claim 1]**
[Text of the initial Claim 1 as filed]

**[First Rejection of Claim 1]**
[Details of the first rejection of Claim 1, explaining how D1/D2 etc. were applied]

**[Response to first rejection]**
[Summary of the applicant's arguments specific to Claim 1]

**[First Amendment of Claim 1]**
[Show the exact amendments made to Claim 1. Use strikethrough for deletions and bold for additions if possible, or clearly describe the changes.]

**[Second Rejection of Claim 1]**
[Details of the second rejection of the amended Claim 1]

**[Response to second rejection]**
[Summary of the applicant's arguments specific to the amended Claim 1]

**[Second Amendment of Claim 1]**
[Show the exact amendments made to Claim 1.]

... (continue this pattern for all office actions affecting Claim 1) ...

**[Final Allowed Claim 1]**
[Text of the final, allowed version of Claim 1]

---
NOW, ANALYZE THE DOCUMENT(S) YOU ARE GIVEN AND GENERATE THE OUTPUT FOLLOWING ALL INSTRUCTIONS AND THE TEMPLATE, FOCUSING EXCLUSIVELY ON CLAIM 1, AND ENSURING YOU HAVE COMPLETED THE 3-STEP VERIFICATION PROCESS FOR MAXIMUM ACCURACY.`;
            const promptParts: any[] = [{ text: prompt }];

            for (const file of fileHistoryFiles) {
                promptParts.push(await fileToPart(file));
            }

            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash-preview-04-17",
                contents: { parts: promptParts },
            });
            setFileHistoryResult(response.text);

        } catch (err) {
            setError(err instanceof Error ? err.message : "An unknown error occurred during file history analysis.");
        } finally {
            setIsFileHistoryLoading(false);
        }
    };
    
    const handleGeneratePriorityAnalysis = async () => {
        if (!priorityClaimText.trim() || !priorityDoc) {
            setError("Please provide both a claim and a priority document.");
            return;
        }
        setIsPriorityDocLoading(true);
        setError("");
        setPriorityDocResult("");

        try {
            const prompt = `You are a meticulous patent analyst specializing in priority claim analysis. Your task is to determine the level of support for each feature of the provided 'Claim Text' within the provided 'Priority Document'.

**Definitions:**
- **Direct Disclosure:** The feature is explicitly and unambiguously described in the priority document.
- **Inferential Disclosure:** The feature is not explicitly stated, but a person skilled in the art would reasonably and directly infer its presence from the text or drawings.
- **No Disclosure:** The feature is not mentioned, either directly or by inference.

**Internal Verification Process for Highest Accuracy:**
To ensure the highest quality output, you MUST follow this internal three-step verification process before providing the final answer. This is your internal thought process and should not be in the output.
1.  **Step 1 (Analyze & Categorize):** Read the claim and the priority document. Perform an initial analysis and categorize each distinct feature of the claim.
2.  **Step 2 (Justify & Cite):** For each categorized feature, write down your justification. Find and note the specific supporting text, page number, line number, or figure from the priority document that proves your categorization.
3.  **Step 3 (Verify & Finalize - The Final Loop):** Critically review your entire analysis from Step 2. Re-read your justifications and double-check your citations against the document. Correct any errors or misinterpretations. Only after this final verification loop should you generate the output.

**Output Instructions:**
Present your analysis in a clear, structured markdown format. For each feature of the claim, state its disclosure category and provide a brief justification.

---
**INPUT CLAIM TEXT:**
${priorityClaimText}
---

NOW, ANALYZE THE ATTACHED PRIORITY DOCUMENT BASED ON THE CLAIM TEXT AND THE INSTRUCTIONS ABOVE. PROVIDE THE FINAL, VERIFIED ANALYSIS.`;
            const promptParts: any[] = [{ text: prompt }, await fileToPart(priorityDoc)];

            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash-preview-04-17",
                contents: { parts: promptParts },
            });
            setPriorityDocResult(response.text);

        } catch (err) {
            setError(err instanceof Error ? err.message : "An unknown error occurred during priority document analysis.");
        } finally {
            setIsPriorityDocLoading(false);
        }
    };
    
    const handleGenerateComplaintAnalysis = async () => {
        if (!complaintPatentNumber.trim() || !complaintDoc) {
            setError("Please provide both a patent number and a complaint document.");
            return;
        }
        setIsComplaintDocLoading(true);
        setError("");
        setComplaintDocResult("");

        try {
            const prompt = `You are an expert patent litigation analyst. Your task is to analyze the provided complaint document and extract only the information relevant to the specific patent number: ${complaintPatentNumber}.

**Instructions:**
1.  **Focus on Specific Patent:** Scrutinize the complaint document and find all mentions, allegations, and mappings related to patent number ${complaintPatentNumber}. Ignore all information related to other patents mentioned in the document.
2.  **Strictly Follow Example Format:** Structure your output to match the example provided below. Your analysis must identify the plaintiffs and defendants, summarize the key infringement allegations against the specified patent, and suggest relevant prior art search strategies based on those allegations.
3.  **Internal Verification Process for Highest Accuracy:** Before producing the final output, you must internally follow a three-step process. This is for your own thinking process and should not be part of the final output.
    *   **Step 1 (Extract):** Read the entire complaint document and pull out every sentence and claim chart related to the patent number: ${complaintPatentNumber}.
    *   **Step 2 (Structure & Summarize):** Organize the extracted information into the required output template format. Summarize the key allegations and formulate search strategies based *only* on the infringement claims in the document.
    *   **Step 3 (Verify & Refine - The Final Loop):** Critically review your structured output from Step 2. Compare it one last time against the source document to verify every detail is accurate and pertains *only* to the specified patent. Correct any errors. Only after this final verification loop should you provide the output.

---
**EXAMPLE OUTPUT TEMPLATE:**

"We have reviewed the complaint document. Our analysis indicates that this case involves a dispute between Valtrus Innovations Ltd. & Key Patent Innovations Ltd. (Plaintiffs) and The Home Depot, Inc. & Home Depot U.S.A., Inc. (Defendants). Below are several key observations regarding the US 7,068,597 patent:
• Home Depot's use of Google Cloud Platform (GCP), specifically its load balancing services (IAM for Cloud Load Balancing, Backend service-based external TCP/UDP Network Load Balancing, and External HTTP(S) Load Balancing), is accused of infringing the '597 patent.
• The complaint alleges that GCP's load balancers receive client requests, mark them with identifiers (like source IP), and intercept these requests before they reach backend servers, corresponding to elements of the '597 patent's claimed method for load balancing.
• GCP's system of using forwarding rules, URL maps, and considering backend server capabilities/load factors to distribute traffic across multiple backend instances is mapped to the '597 patent's description of anplying rules to assign requests to channel pairs based on device capabilities and network conditions.
• The functionality of connection tracking and session affinity within GCP's load balancing services is presented as infringing elements related to managing client connections to specific backend resources.
• Using these observations from this complaint document, we will conduct searches using strategies such as "Dynamic Network Request Distribution," "Rule-Based Load Balancing," "Client-Server Session Management in Distributed Systems," and "Cloud Load Balancing Architectures (pre-dating the patent)" to identify relevant prior art for the '597 patent."

---
NOW, ANALYZE THE ATTACHED COMPLAINT DOCUMENT BASED ON PATENT NUMBER ${complaintPatentNumber} AND THE INSTRUCTIONS. PROVIDE THE FINAL, VERIFIED ANALYSIS.`;
            const promptParts: any[] = [{ text: prompt }, await fileToPart(complaintDoc)];

            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash-preview-04-17",
                contents: { parts: promptParts },
            });
            setComplaintDocResult(response.text);

        } catch (err) {
            setError(err instanceof Error ? err.message : "An unknown error occurred during complaint document analysis.");
        } finally {
            setIsComplaintDocLoading(false);
        }
    };

    const handleGenerateIprAnalysis = async () => {
        if (!iprPatentNumber.trim() || !iprDoc) {
            setError("Please provide both a patent number and an IPR document.");
            return;
        }
        setIsIprDocLoading(true);
        setError("");
        setIprDocResult("");

        try {
            const prompt = `You are an expert patent analyst specializing in Inter Partes Review (IPR) proceedings. Your task is to analyze the provided IPR document and extract only the information relevant to the specific patent number: ${iprPatentNumber}.

**Instructions:**
1.  **Focus on Specific Patent:** Scrutinize the document and find all arguments, evidence, and decisions related to patent number ${iprPatentNumber}. Ignore all information related to other patents.
2.  **Identify Key Elements:** Your analysis should identify:
    *   The petitioner and patent owner.
    *   The specific claims of patent ${iprPatentNumber} that were challenged.
    *   The grounds for invalidity asserted against the claims (e.g., anticipation under § 102, obviousness under § 103).
    *   The prior art references cited in the IPR.
    *   A summary of the petitioner's main arguments for invalidity.
    *   A summary of the patent owner's main arguments defending the patent.
    *   The key findings or decision made by the Patent Trial and Appeal Board (PTAB) in the document.
3.  **Internal Verification Process for Highest Accuracy:** Before producing the final output, you must internally follow a three-step process. This is for your own thinking process and should not be part of the final output.
    *   **Step 1 (Extract):** Read the entire IPR document and pull out every sentence, paragraph, and claim chart related to patent number ${iprPatentNumber} and its challenged claims.
    *   **Step 2 (Structure & Summarize):** Organize the extracted information into a logical narrative. Summarize the key arguments from both sides and the board's decision.
    *   **Step 3 (Verify & Refine - The Final Loop):** Critically review your structured output from Step 2. Compare it one last time against the source document to verify every detail is accurate and pertains *only* to the specified patent. Ensure the grounds for rejection and the specific prior art are correctly identified. Only after this final verification loop should you provide the output.
4.  **Output Format:** Present the analysis in clear, well-structured markdown. Use headings and bullet points for readability.

---
NOW, ANALYZE THE ATTACHED IPR DOCUMENT BASED ON PATENT NUMBER ${iprPatentNumber} AND THE INSTRUCTIONS. PROVIDE THE FINAL, VERIFIED ANALYSIS.`;
            const promptParts: any[] = [{ text: prompt }, await fileToPart(iprDoc)];

            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash-preview-04-17",
                contents: { parts: promptParts },
            });
            setIprDocResult(response.text);

        } catch (err) {
            setError(err instanceof Error ? err.message : "An unknown error occurred during IPR document analysis.");
        } finally {
            setIsIprDocLoading(false);
        }
    };


    const handleGenerateEmail = async () => {
        setIsEmailLoading(true);
        setError("");
        setEmailResult("");

        try {
            let overviewContent = understandingResult;
            if (understandingResult) {
                const summarizationPrompt = `Summarize the following 'Understanding' analysis into a single, professional paragraph of less than 200 words. This summary will be used for the '[Overview of the Invention]' section of a formal update email.

---
TEXT TO SUMMARIZE:
${understandingResult}
---`;
                const summaryResponse = await ai.models.generateContent({
                    model: 'gemini-2.5-flash-preview-04-17',
                    contents: summarizationPrompt,
                });
                overviewContent = summaryResponse.text;
            } else {
                overviewContent = "No understanding analysis has been generated yet. Please provide a summary of the invention.";
            }

            const prompt = `You are an expert patent analyst and legal assistant. Your task is to generate a professional "First Update" email by combining the information provided below. You MUST follow the structure and example provided.

**EMAIL STRUCTURE & INSTRUCTIONS:**

1.  **Greeting:** Start with "Hi ABC,".
2.  **Opening Line:** Start with a line like "We have initiated the search for XX'XXX and have come across a couple of interesting findings...".
3.  **[Overview of the Invention]:**
    *   Use the "OVERVIEW OF THE INVENTION" text provided below for this section. This text is already summarized for you.
    *   This section should be less than 200 words.
4.  **[Identified References]:**
    *   Use the "INPUT RESULTS WITH SUMMARY" text provided below for this section.
5.  **[Observations/Next Steps]:**
    *   This is a critical section. You MUST use your web search capabilities to generate three to four intelligent, non-obvious points.
    *   These points should look like they have been written after a quality search.
    *   Suggest tracking related standards, assignee portfolios, key inventors, or relevant non-patent literature.
6.  **Closing:**
    *   Include a closing sentence like "We will be waiting for your feedback on our initial set of results...".
    *   End with "Best Regards,\nXYZ".

---
**PROVIDED INFORMATION FOR EMAIL DRAFTING:**

**1. Overview of the Invention (Use this for the [Overview of the Invention] section):**
${overviewContent}

**2. Identified References (Use this for the [Identified References] section):**
${emailInputResults || "No specific results or references were provided in the input."}

**3. Extra Input from User (Use this for additional context):**
${emailExtraInput || "No extra input provided."}

**4. Additional Context from Other Analyses (Do NOT copy this verbatim, use it to inform the tone and content of the opening and observation sections):**
- File History Analysis Summary: ${fileHistoryResult || "Not analyzed."}
- Priority Document Analysis Summary: ${priorityDocResult || "Not analyzed."}
- Complaint Document Analysis Summary: ${complaintDocResult || "Not analyzed."}
- IPR Document Analysis Summary: ${iprDocResult || "Not analyzed."}

---
**EXAMPLE EMAIL (THIS IS YOUR GOAL - MATCH THIS STYLE, TONE, AND FORMAT EXACTLY):**

"Hi ABC,

We have initiated the search for US’061 and have come across couple of interesting findings out of which US20160269872A1 (Kim et al.) seems to be a 102 type art. Before diving into the details, let me give you a quick summary of the target patent and the main elements of the invention to make sure we’re on the same page. Please let me know if there’s anything we might have missed.

[Overview of the Invention]

US'061 discloses a wireless communication method implemented by a user equipment, which involves establishing a mapping of coded bits from a physical broadcast channel (PBCH) or beamformed reference signals (BRS) to tones within a symbol of a subframe, where this mapping remains consistent regardless of system bandwidth. This involves splitting the coded bits of one transmission period into multiple smaller segments, mapping each segment to frequency tones starting at a fixed, predefined offset relative to a known reference point that remains unchanged despite the total number of available tones, subsequently monitoring the symbol for the PBCH or BRS based on this mapping.

We also reviewed the prosecution history of the target patent and identified above highlighted parts as the key aspect of the invention. Detailed analyses of the invention and the prosecution history can be found in Sections 3 and 4 of the attached report for your reference.

[Identified References]

Regarding the identified references, we got our hands on US20160269872A1 (Kim et al.) and KR20140080296A (Park) A brief summary of each is as follows:

Kim discloses a method performed by a user equipment (UE) that involves determining a mapping for Physical Broadcast Channel (PBCH) coded bits onto resource elements (tones/symbols) within specific subframes. It seems to describe this PBCH mapping as independent of system bandwidth, utilizing center subcarriers for legacy PBCH, and includes segmenting a 40ms PBCH transmission period into distinct coded bit blocks, such as PBCH(0) to PBCH(3). The patent also broadly supports mapping these segments from their starting points onto available resources, regardless of whether truncation or repetition/cycling occurs, which seems to align with the idea of a "fixed starting offset." Additionally, the UE’s role in monitoring and decoding the PBCH also seems to be discussed. However, there is no explicit mention of Beamformed Reference Signals (BRS), with all discussions centering solely on the mapping and monitoring of the PBCH. 

Park discloses a method where the User Equipment (UE) determines the mapping of PBCH coded bits onto resource elements defined by frequency tones and time symbols. The coded bits are distributed over four consecutive radio frames starting from a defined point, but resource elements allocated for reference signals are skipped. This contradicts the claim that mapping occurs "regardless of available resource," as availability affects mapping. The UE derives the mapping by monitoring the PBCH. However, Park does not disclose a fixed starting offset and doesn’t seem to disclose the feature of mapping being independent of system bandwidth.

A detailed analysis of these references is available in the Section 2 of the attached report. You can also refer to claim matrix of Kim in Section 1 of the attached report for feature wise mapping.

[Observations/Next Steps]

We also tried to track the invention on non-patent front where we came across an article An overview of the LTE physical layer - Part III. This article from 2010 (well before the cut-off date) describes an LTE PBCH mapping approach that appears to have bandwidth-agnostic characteristics. The PBCH is mapped to a fixed number of center sub-carriers regardless of the overall system bandwidth. However, the article doesn't describe mapping to multiple segments with fixed starting offsets. We are planning to track relevant work of the author of this article. On patent front, we noticed that LG (assignee of Kim et al.) and Samsung has relevant work in this domain like we came across a patent from Samsung US20080081603A1 (Cho et al.) which seem to discuss the method of transmitting PBCH but misses out on key features. We are tracking these assignees on both patent and non-patent front.

We also went through the standard analysis shared from your side and are in agreement with that. Further, we are tracking the 3GPP submissions or discussion related to the development of this invention in the standard.

So, this will be all from our side in this update. We will be waiting for your feedback on our initial set of results. Please let us know if you have any queries or any disagreement regarding our search direction.

Best Regards,
XYZ"

---
NOW, GENERATE THE EMAIL BASED ON THE PROVIDED INFORMATION AND THE STRICT INSTRUCTIONS.
`;

            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash-preview-04-17",
                contents: prompt,
                 config: {
                    tools: [{googleSearch: {}}]
                }
            });
            setEmailResult(response.text);

        } catch (err) {
            setError(err instanceof Error ? err.message : "An unknown error occurred while generating the email.");
        } finally {
            setIsEmailLoading(false);
        }
    };

    const renderActiveTabContent = () => {
        switch (activeTab) {
            case "Understanding":
                return (
                    <div className="tab-pane">
                        <div className="form-group">
                           <FileInputComponent file={understandingFile} onFileChange={setUnderstandingFile} label="Subject Patent Document"/>
                        </div>
                        <button onClick={handleGenerateUnderstanding} disabled={isUnderstandingLoading}>
                            {isUnderstandingLoading ? "Analyzing..." : "Generate Understanding"}
                        </button>
                        {isUnderstandingLoading && <LoadingComponent />}
                        {understandingResult && (
                             <div className="result-card">
                                <h3>Generated Understanding</h3>
                                <CopyButton textToCopy={understandingResult} />
                                <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(understandingResult || '')}}></div>
                            </div>
                        )}
                    </div>
                );
            case "File History":
                return (
                     <div className="tab-pane">
                        <div className="file-input-wrapper">
                            <label>Attach File History</label>
                             <div
                                className="file-drop-zone"
                                onClick={() => fileHistoryInputRef.current?.click()}
                                onDrop={handleFileHistoryDrop}
                                onDragOver={handleFileHistoryDragOver}
                            >
                                <input
                                    type="file"
                                    multiple
                                    ref={fileHistoryInputRef}
                                    onChange={handleFileHistoryChange}
                                    style={{ display: 'none' }}
                                    accept=".pdf,.doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                />
                                {fileHistoryFiles.length > 0 ? (
                                    <div className="multi-file-display">
                                        {fileHistoryFiles.map((file, index) => (
                                            <div className="file-display" key={`${file.name}-${index}`}>
                                                <DocumentIcon />
                                                <span className="file-display-name">{file.name}</span>
                                                <button onClick={(e) => { e.stopPropagation(); handleRemoveFileHistoryFile(index); }} className="remove-file-button" aria-label="Remove file">
                                                    <CloseIcon />
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <span>Click or drag & drop file(s) here</span>
                                )}
                            </div>
                        </div>
                        <button onClick={handleGenerateFileHistoryAnalysis} disabled={isFileHistoryLoading || fileHistoryFiles.length === 0}>
                            {isFileHistoryLoading ? "Analyzing..." : "Generate Analysis"}
                        </button>
                        {isFileHistoryLoading && <LoadingComponent />}
                        {fileHistoryResult && (
                            <div className="result-card">
                                <h3>Generated File History Analysis</h3>
                                <CopyButton textToCopy={fileHistoryResult} />
                                <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(fileHistoryResult || '')}}></div>
                            </div>
                        )}
                    </div>
                );
            case "Priority Document Analyzer":
                return (
                    <div className="tab-pane">
                        <div className="form-group">
                            <label htmlFor="priority-claim-text">Claim</label>
                            <textarea
                                id="priority-claim-text"
                                value={priorityClaimText}
                                onChange={(e) => setPriorityClaimText(e.target.value)}
                                placeholder="Paste the claim text to analyze..."
                            />
                        </div>
                        <div className="form-group">
                           <FileInputComponent file={priorityDoc} onFileChange={setPriorityDoc} label="Upload Priority Document"/>
                        </div>
                        <button onClick={handleGeneratePriorityAnalysis} disabled={isPriorityDocLoading || !priorityClaimText.trim() || !priorityDoc}>
                            {isPriorityDocLoading ? "Analyzing..." : "Generate Analysis"}
                        </button>
                        {isPriorityDocLoading && <LoadingComponent />}
                        {priorityDocResult && (
                             <div className="result-card">
                                <h3>Generated Analysis</h3>
                                <CopyButton textToCopy={priorityDocResult} />
                                <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(priorityDocResult || '')}}></div>
                            </div>
                        )}
                    </div>
                );
            case "Complaint Document Analyzer":
                return (
                    <div className="tab-pane">
                        <div className="form-group">
                            <label htmlFor="complaint-patent-number">Patent Number</label>
                            <input
                                type="text"
                                id="complaint-patent-number"
                                value={complaintPatentNumber}
                                onChange={(e) => setComplaintPatentNumber(e.target.value)}
                                placeholder="Enter patent number to analyze..."
                            />
                        </div>
                        <div className="form-group">
                           <FileInputComponent file={complaintDoc} onFileChange={setComplaintDoc} label="Upload Complaint Document"/>
                        </div>
                        <button onClick={handleGenerateComplaintAnalysis} disabled={isComplaintDocLoading || !complaintPatentNumber.trim() || !complaintDoc}>
                            {isComplaintDocLoading ? "Analyzing..." : "Generate Analysis"}
                        </button>
                        {isComplaintDocLoading && <LoadingComponent />}
                        {complaintDocResult && (
                             <div className="result-card">
                                <h3>Generated Analysis</h3>
                                <CopyButton textToCopy={complaintDocResult} />
                                <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(complaintDocResult || '')}}></div>
                            </div>
                        )}
                    </div>
                );
            case "IPR Analyzer":
                return (
                    <div className="tab-pane">
                        <div className="form-group">
                            <label htmlFor="ipr-patent-number">Patent Number</label>
                            <input
                                type="text"
                                id="ipr-patent-number"
                                value={iprPatentNumber}
                                onChange={(e) => setIprPatentNumber(e.target.value)}
                                placeholder="Enter patent number to analyze..."
                            />
                        </div>
                        <div className="form-group">
                           <FileInputComponent file={iprDoc} onFileChange={setIprDoc} label="Upload IPR Document"/>
                        </div>
                        <button onClick={handleGenerateIprAnalysis} disabled={isIprDocLoading || !iprPatentNumber.trim() || !iprDoc}>
                            {isIprDocLoading ? "Analyzing..." : "Generate Analysis"}
                        </button>
                        {isIprDocLoading && <LoadingComponent />}
                        {iprDocResult && (
                             <div className="result-card">
                                <h3>Generated IPR Analysis</h3>
                                <CopyButton textToCopy={iprDocResult} />
                                <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(iprDocResult || '')}}></div>
                            </div>
                        )}
                    </div>
                );
            case "Generate Email":
                 return (
                    <div className="tab-pane">
                        <div className="form-group">
                            <label htmlFor="email-input-results">Input Results with summary</label>
                            <textarea
                                id="email-input-results"
                                value={emailInputResults}
                                onChange={(e) => setEmailInputResults(e.target.value)}
                                placeholder="Paste your analysis of identified references here..."
                                rows={8}
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="email-extra-input">Extra input (optional)</label>
                            <textarea
                                id="email-extra-input"
                                value={emailExtraInput}
                                onChange={(e) => setEmailExtraInput(e.target.value)}
                                placeholder="Add any extra notes or context for the email..."
                                rows={4}
                            />
                        </div>
                        <button onClick={handleGenerateEmail} disabled={isEmailLoading}>
                            {isEmailLoading ? "Generating Email..." : "Generate Email"}
                        </button>
                        {isEmailLoading && <LoadingComponent />}
                        {emailResult && (
                             <div className="result-card">
                                <h3>Generated Email</h3>
                                <CopyButton textToCopy={emailResult} />
                                <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(emailResult || '')}}></div>
                            </div>
                        )}
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div className="page first-update-page">
            <div className="page-header-container">
                <h1 className="page-header">First Update</h1>
                <button onClick={handleClearAll} className="clear-all-button" aria-label="Clear all data">
                    <RefreshIcon />
                    Clear All
                </button>
            </div>
            <div className="tabs-container">
                {TABS.map(tab => (
                    <button 
                        key={tab} 
                        className={`tab-button ${activeTab === tab ? 'active' : ''}`}
                        onClick={() => setActiveTab(tab)}
                    >
                        {tab}
                    </button>
                ))}
            </div>
            <div className="tab-content">
                 {error && <div className="error-message">{error}</div>}
                 {renderActiveTabContent()}
            </div>
        </div>
    );
};

// --- TYPES for Claim Chart ---
type ColoredText = {
  text: string;
  color: string;
};

type ReferenceContent = {
  text: string;
  color: string | null; // null for non-highlighted text
};

type ClaimChartRow = {
  claimElement: ColoredText[];
  referenceText: {
    citation: string;
    content: ReferenceContent[];
  };
  comment: string;
  result: 'Supported' | 'Inferentially Supported' | 'Partially Supported' | 'Not Supported';
};

const ClaimChartView = () => {
    const [claims, setClaims] = useState("");
    const [priorArt, setPriorArt] = useState("");
    const [chartData, setChartData] = useState<ClaimChartRow[] | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState("");

    const handleSubmit = async () => {
        if (!claims.trim() || !priorArt.trim()) {
            setError("Please provide both claims and the reference text.");
            return;
        }
        setIsLoading(true);
        setError("");
        setChartData(null);

        try {
            const prompt = `
You are Google's most intelligent patent analysis model. Your task is to create a detailed, color-coded claim chart comparing patent claims against a prior art reference. You MUST achieve the highest possible accuracy by following a strict verification process.

**Internal Triple-Verification Loop (Mandatory Process):**
Before generating the final output, you MUST execute this internal iterative process. This process is for your internal reasoning and the final output should only be the JSON.
1.  **Loop 1 (Initial Analysis):** Deconstruct the claim into individual, meaningful elements. Perform a first pass on the reference text to find potentially matching sections for each element.
2.  **Loop 2 (Critical Mapping & Coloring):**
    *   Rigorously re-evaluate the mappings.
    *   Assign unique, non-black colors to distinct phrases in the claim elements. Avoid reusing colors across unrelated phrases.
    *   For long claim clauses (over 40 words), you MUST use at least three different colors to break the clause down into smaller conceptual parts.
    *   Find the corresponding text in the reference and apply the exact same colors to the matching phrases.
    *   Quote the complete paragraph(s) for the reference text. If support spans multiple paragraphs, include all of them in the format "[Para XXXX...Para YYYY]".
    *   Formulate a detailed comment and an accurate comparison result for each element.
3.  **Loop 3 (Final Verification & JSON Assembly):** Conduct a final, word-by-word review of your entire analysis from Loop 2. Verify all color mappings, citations, comments, and results for absolute accuracy and consistency. Only after this final check, assemble the verified data into the final JSON output.

**Color-Coding Rules:**
-   Use **text color**, not background highlighting.
-   Use the provided list of distinct colors. **Do NOT use black** or shades of grey for highlighting colored phrases.
-   Assign a unique color to each significant phrase (e.g., "distributed processing system," "network," "client systems").
-   Apply the **same color** to a phrase in the claim and its EXACT matching phrase in the reference text for a one-to-one mapping.
-   Avoid reusing colors across unrelated phrases.

**Output Format Rules:**
- Your final output MUST be a single, perfectly structured JSON object. Do not include any other text or explanations outside of this JSON object.
- **CRITICAL JSON RULE:** When generating the JSON, ensure all string values are properly escaped. Pay special attention to double quotes (") within your text content (like in the "comment" or "text" fields). These MUST be escaped with a backslash (e.g., "some text with a \\"quote\\" in it"). Failure to do so will result in an invalid JSON.

**JSON Structure:**
{
  "chart": [
    {
      "claimElement": [
        {"text": "A segment of the claim element...", "color": "#D32F2F"},
        {"text": "another segment...", "color": "#007BFF"}
      ],
      "referenceText": {
        "citation": "A precise citation, e.g., '[Para 0023]' or '[Para 0045 - Para 0047]' or '[Col. 2, Lines 16-25]'",
        "content": [
          {"text": "The full text from the reference paragraph...", "color": null},
          {"text": "the matching text segment...", "color": "#D32F2F"},
          {"text": "more non-matching text from the paragraph...", "color": null}
        ]
      },
      "comment": "Your expert analysis on how the prior art maps to the claim element. Clarify any assumptions or interpretations made.",
      "result": "One of: 'Supported', 'Inferentially Supported', 'Partially Supported', or 'Not Supported'"
    }
  ]
}

**Available Colors for Highlighting:**
#D32F2F, #007BFF, #28A745, #FFC107, #6F42C1, #FD7E14, #20C997, #17A2B8

---
**INPUTS:**

**Claim Text:**
${claims}

**Reference Text:**
${priorArt}
---

NOW, EXECUTE THE TRIPLE-VERIFICATION LOOP AND PROVIDE THE SINGLE, FLAWLESSLY ACCURATE AND VALID JSON OUTPUT.
`;
            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash-preview-04-17",
                contents: prompt,
                config: {
                    responseMimeType: "application/json"
                }
            });

            const responseText = response.text;
            if (!responseText) {
                throw new Error("Received an empty response from the model. Please try again.");
            }

            let jsonStr = responseText.trim();
            const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
            const match = jsonStr.match(fenceRegex);
            if (match && match[2]) {
              jsonStr = match[2].trim();
            }
            
            const parsedResult = JSON.parse(jsonStr);
            if (parsedResult.chart && Array.isArray(parsedResult.chart)) {
                 setChartData(parsedResult.chart);
            } else {
                throw new Error("The model's response did not contain a valid 'chart' array.");
            }

        } catch (err) {
            setError(err instanceof Error ? `Failed to analyze or parse response: ${err.message}` : "An unknown error occurred.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    const handleDownload = () => {
        if (!chartData) return;

        const tableRows = chartData.map(row => {
            const claimElementHtml = row.claimElement.map(part => 
                `<span style='color:${part.color};'>${part.text.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</span>`
            ).join('');

            const referenceTextHtml = row.referenceText.content.map(part => 
                `<span style='color:${part.color || '#000000'};'>${part.text.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</span>`
            ).join('');

            const commentHtml = row.comment.replace(/</g, '&lt;').replace(/>/g, '&gt;');
            const resultHtml = row.result.replace(/</g, '&lt;').replace(/>/g, '&gt;');
            const citationHtml = row.referenceText.citation.replace(/</g, '&lt;').replace(/>/g, '&gt;');

            return `
                <tr>
                    <td style='padding: 5px; vertical-align: top;'>${claimElementHtml}</td>
                    <td style='padding: 5px; vertical-align: top;'>
                        <b>${citationHtml}</b><br/>
                        ${referenceTextHtml}
                    </td>
                    <td style='padding: 5px; vertical-align: top;'>${commentHtml}</td>
                    <td style='padding: 5px; vertical-align: top;'>${resultHtml}</td>
                </tr>
            `;
        }).join('');

        const htmlString = `
            <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
                <head>
                    <meta charset='utf-8'>
                    <title>Claim Chart</title>
                    <style>
                        @page {
                            mso-page-orientation: landscape;
                            size: 29.7cm 21cm; /* A4 landscape */
                            margin: 1.27cm;
                        }
                        body { font-family: 'Segoe UI', sans-serif; font-size: 10pt; }
                        table, th, td { border: 1px solid black; border-collapse: collapse; }
                        th, td { padding: 5px; text-align: left; vertical-align: top; }
                        th { background-color: #f2f2f2; }
                    </style>
                </head>
                <body>
                    <h2>Claim Chart</h2>
                    <table style='width:100%;'>
                        <thead>
                            <tr>
                                <th>Claim Element</th>
                                <th>Text from Reference</th>
                                <th>Comment on Comparison</th>
                                <th>Comparison Result</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${tableRows}
                        </tbody>
                    </table>
                </body>
            </html>
        `;

        const blob = new Blob(['\ufeff', htmlString], {
            type: 'application/msword'
        });

        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = "claim_chart.doc";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    return (
        <div className="page claim-chart-page">
            <h1 className="page-header">Claim Chart Generator</h1>
            <div className="form-group">
                <label htmlFor="claims-text">Claim</label>
                <textarea
                    id="claims-text"
                    value={claims}
                    onChange={(e) => setClaims(e.target.value)}
                    placeholder="Paste the patent claim(s) here..."
                />
            </div>
            <div className="form-group">
                <label htmlFor="prior-art-text">Text from Reference</label>
                <textarea
                    id="prior-art-text"
                    value={priorArt}
                    onChange={(e) => setPriorArt(e.target.value)}
                    placeholder="Paste the prior art document text here..."
                />
            </div>
            <button onClick={handleSubmit} disabled={isLoading || !claims.trim() || !priorArt.trim()}>
                {isLoading ? "Generating..." : "Generate Claim Chart"}
            </button>
            {isLoading && <LoadingComponent />}
            {error && <div className="error-message">{error}</div>}
            {chartData && (
                <div className="result-card">
                    <div className="result-card-header">
                        <h3>Generated Claim Chart</h3>
                        <button onClick={handleDownload} className="download-button">Download Claim Chart (.doc)</button>
                    </div>
                    <div className="claim-chart-container">
                        <table className="claim-chart-table">
                            <thead>
                                <tr>
                                    <th>Claim Element</th>
                                    <th>Text from Reference</th>
                                    <th>Comment on Comparison</th>
                                    <th>Comparison Result</th>
                                </tr>
                            </thead>
                            <tbody>
                                {chartData.map((row, index) => (
                                    <tr key={index}>
                                        <td>
                                            {row.claimElement.map((part, i) => (
                                                <span key={i} style={{ color: part.color }}>{part.text}</span>
                                            ))}
                                        </td>
                                        <td>
                                            <strong>{row.referenceText.citation}</strong>
                                            <div style={{ marginTop: '5px' }}>
                                                {row.referenceText.content.map((part, i) => (
                                                    <span key={i} style={{ color: part.color || 'inherit' }}>{part.text}</span>
                                                ))}
                                            </div>
                                        </td>
                                        <td>{row.comment}</td>
                                        <td>{row.result}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
};

const TranslationView = () => {
    const [file, setFile] = useState<File | null>(null);
    const [translatedText, setTranslatedText] = useState("");
    const [isTranslating, setIsTranslating] = useState(false);
    const [error, setError] = useState("");

    const handleFileChange = (selectedFile: File | null) => {
        setFile(selectedFile);
        setTranslatedText(""); // Clear previous results
        setError("");
    };

    const handleTranslate = async () => {
        if (!file) {
            setError("Please attach a document to translate.");
            return;
        }

        setIsTranslating(true);
        setTranslatedText("");
        setError("");

        try {
            const prompt = `You are an expert translator. Your task is to translate the entire content of the attached document into English. Provide a complete, word-for-word translation. Maintain the original document's structure, including paragraphs and line breaks, as closely as possible. The output should ONLY be the translated English text, with no additional commentary, headings, or explanations from you. Start translating immediately from the first word of the document and continue streaming the translation until the very end. Do not stop until the entire document is translated.`;

            const filePart = await fileToPart(file);

            const responseStream = await ai.models.generateContentStream({
                model: "gemini-2.5-flash-preview-04-17",
                contents: [{ parts: [{ text: prompt }, filePart] }],
            });

            let fullText = "";
            for await (const chunk of responseStream) {
                const chunkText = chunk.text;
                fullText += chunkText;
                setTranslatedText(fullText); // Stream output to UI
            }

        } catch (err) {
            setError(err instanceof Error ? err.message : "An unknown error occurred during translation.");
        } finally {
            setIsTranslating(false);
        }
    };
    
    const handleDownloadDoc = () => {
        if (!translatedText || !file) return;

        const baseFilename = file.name.substring(0, file.name.lastIndexOf('.'));
        const filename = `${baseFilename}_translated.doc`;

        const htmlContent = `<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body>${translatedText.replace(/\n/g, '<br>')}</body></html>`;
        const blob = new Blob([htmlContent], { type: 'application/msword' });

        const link = document.createElement("a");
        const url = URL.createObjectURL(blob);
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    return (
        <div className="page translation-page">
            <h1 className="page-header">Translation</h1>
            <div className="form-group">
                <p className="page-description">Upload a PDF or Word document. The model will perform a complete, page-by-page translation into English and provide downloadable files.</p>
                <FileInputComponent file={file} onFileChange={handleFileChange} label="Document to Translate" />
            </div>
            <button onClick={handleTranslate} disabled={isTranslating || !file}>
                {isTranslating ? "Translating..." : "Generate Translation"}
            </button>

            {isTranslating && !translatedText && <LoadingComponent />}
            {error && <div className="error-message">{error}</div>}
            
            {(isTranslating || translatedText) && (
                <div className="result-card">
                    <div className="result-card-header">
                        <h3>{isTranslating ? 'Translating in progress...' : 'Translated Text'}</h3>
                        {!isTranslating && translatedText && (
                            <div className="download-buttons">
                                <button className="download-button" onClick={handleDownloadDoc}>Download as Word (.doc)</button>
                            </div>
                        )}
                    </div>
                     <pre className="translation-output">{translatedText}{isTranslating && <span className="blinking-cursor"></span>}</pre>
                </div>
            )}
        </div>
    );
};

const OrbitStringsView = () => {
    const [claim, setClaim] = useState("");
    const [numStrings, setNumStrings] = useState("3");
    const [cutoffDate, setCutoffDate] = useState("");
    const [specificFeature, setSpecificFeature] = useState("");
    const [result, setResult] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState("");

    const handleSubmit = async () => {
        if (!claim.trim() || !cutoffDate.trim() || !numStrings) {
            setError("Please provide a Claim, Number of Strings, and a Cut-off Date.");
            return;
        }
        setIsLoading(true);
        setError("");
        setResult("");

        try {
            const prompt = `
You are an expert patent analyst who specializes in crafting highly effective search strings for the Orbit patent search engine. Your goal is to generate search strings that find the most relevant prior art with strong similarity to an input claim.

You MUST generate strings using the correct Orbit syntax. Here are the rules and operators you must adhere to:

**Operators:**
- OR: Finds records with at least one term (e.g., "Dual OR Double").
- AND: Finds records with all terms (e.g., "plutonium AND isotope").
- NOT: Excludes records with the second term (e.g., "suv NOT vehicle").
- S: Terms in the same sentence (e.g., "sodium S chlorine").
- P: Terms in the same paragraph (e.g., "sodium P chlorine").
- D: Terms adjacent in any order (e.g., "redundancy D check").
- nD: Terms within n words, any order (e.g., "conduct 2D electric").
- W: Terms adjacent in specified order (e.g., "smart W card").
- nW: Terms within n words, specified order (e.g., "friction 9W pad").
- _: Searches for one/two words or hyphenated (e.g., "air_bag").
- Parentheses (): For nesting and combining operators.

**Truncation Operators:**
- +: Replaces any number of characters at the end (e.g., "electric+").
- ?: Replaces zero or one character (e.g., "bicycle?").
- #: Replaces exactly one character (e.g., "polymeri#ation").

**Field Codes:**
- Always apply field codes to your search terms (e.g., /TI/AB/CLMS/TX).
- TI: Title
- AB: Abstract
- CLMS: Claims
- DESC: Description
- TX: Full Text

**Numeric Field Operators & Cut-off Date:**
- Use the provided cut-off date to create a date-limiting clause.
- Common date fields are PRD (priority date) and EPD (earliest priority date). Use EPRD for broad searches.
- The format must be, for example: (EPRD < 2017-01-04) or (PD <= 2009-10-02).
- The clause should be at the end of the query string, combined with AND. Example: (...query...) AND (EPRD < ${cutoffDate})

**Instructions:**
1.  Analyze the provided "Claim" and "Specific Feature" (if any). If a "Specific Feature" is provided, focus the search on that feature, using the claim for context.
2.  Identify the key concepts, terms, and their relationships.
3.  Brainstorm a rich set of synonyms and variations for the key terms. Use truncation operators (+, ?, #) effectively.
4.  Construct ${numStrings} distinct, intelligent search strings. Each string should represent a different search strategy to target the invention.
5.  Use a variety of operators to capture the nuances of the claim. Use complex nesting with parentheses.
6.  Always include the date-limiting clause at the end of each string, inside the main parentheses.
7.  The entire output should be ONLY the generated strings, each on a new line, numbered like "String 1: ...", "String 2: ...". Do not add explanations or any other conversational text.

**Example of High-Quality Strings (for style and syntax reference):**
- String 4: (((SRS OR SOUNDING_REFERENCE OR SOUNDING_RS)/TI/AB/OBJ/ADB/ICLM/TX AND (BEAM_PAIR OR BEAM_SET OR BEAM OR PORT OR PRECODING)/TI/AB/OBJ/ADB/ICLM/TX AND (PUSCH+ OR UPLINK_CHANNEL+ OR PUCCH OR UPLINK_SHARED OR SHARED_CHANNEL OR UP_LINK)/TI/AB/OBJ/ADB/ICLM/TX AND (QCL OR QUASI_CO_LOCAT+)/TI/AB/OBJ/ADB/ICLM/TX AND (TPC OR POWER_CONTROL OR TRANSMISSION_POWER_CONTROL OR TRANSMIT_POWER_CONTROL)/TI/AB/OBJ/ADB/ICLM/TX) AND (EPRD < 2017-01-04))
- String 13: ((((SPLIT+ OR DIVI+ OR SEPERAT+ OR COMPRIS+ OR COMBIN+) 5D (AF OR APPLICATION_FUNCTION?)) P ((AF_CP OR CONTROL_PLANE? OR CP) P (AF_UP OR AF_DP OR USER_PLANE? OR DATA_PLANE? OR FORWARD_PLANE? OR FORWARDING_PLANE?)))/TI/AB/TX AND (PRD < 2017-08-28))
- String 25: ((((Codeword? OR (Code_Word?) OR (Transport_Block?) OR (Data_Block?) OR (Transport_Data) OR (Transmission_Data) OR (Transmission_Code?) OR (Transmission_Block?) OR (Payload_Info+) OR (Info+_Block?) OR (Dl_Data OR Dl_Info+ OR DL_Block)) OR (Ul_Data OR Ul_Info+ OR Ul_Block)) OR ((Down_Link) 2D (Data OR Info+ OR Block)) OR (Downlink 2D (Data OR Info+ OR Block)) OR (Uplink 2D (Data OR Info+ OR Block)) OR ((Up_Link) 2D (Data OR Info+ OR Block)) OR (Transport 2D Block?)) 5D (Divi+ OR Segment+ OR Section+ OR Split+ OR Part+ OR (Sub_Divi+) OR Subdivi+ OR Separat+)) P ((Cbg? OR ((Code_Block?)_Group?) OR ((Code_Block?)_Cluster?) OR ((Ofdm_Symbol?)_Group?) OR ((Code_Block?)_Set?) OR (Ofdm NEAR3 (Block OR Cluster? OR Set? OR Group+2))) S ((Multi+ OR Differ+ OR Plural+ OR Many OR Distinct OR Several OR Numerous OR Group? OR Set?) 5D (Size? OR Dimension? OR Length? OR Width OR Breadth OR Number?)))) AND EPRD<=(2017-06-13))

---
**USER INPUT:**
- Claim: ${claim}
- Number of Strings Required: ${numStrings}
- Cut-off Date: ${cutoffDate}
- Specific Feature: ${specificFeature || "None. Focus on the overall claim."}
---

NOW, GENERATE THE ORBIT STRINGS.`;

            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash-preview-04-17",
                contents: prompt,
            });
            
            setResult(response.text);

        } catch (err) {
            setError(err instanceof Error ? err.message : "An unknown error occurred.");
        } finally {
            setIsLoading(false);
        }
    };
    
    useEffect(() => {
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const dd = String(today.getDate()).padStart(2, '0');
        setCutoffDate(`${yyyy}-${mm}-${dd}`);
    }, []);

    return (
        <div className="page orbit-strings-page">
            <h1 className="page-header">Orbit Strings Generator</h1>
            <p className="page-description">
                Generate intelligent search strings for the Orbit patent search engine. Provide a claim, specify the number of strings, set a cut-off date, and optionally focus on a specific feature.
            </p>
            <div className="orbit-strings-form">
                 <div className="form-group">
                    <label htmlFor="claim-text">Claim</label>
                    <textarea
                        id="claim-text"
                        value={claim}
                        onChange={(e) => setClaim(e.target.value)}
                        placeholder="Paste the patent claim text here..."
                        rows={6}
                    />
                </div>
                 <div className="form-group">
                    <label htmlFor="specific-feature">Specific Feature (Optional)</label>
                    <textarea
                        id="specific-feature"
                        value={specificFeature}
                        onChange={(e) => setSpecificFeature(e.target.value)}
                        placeholder="e.g., 'The mechanism for power control in uplink channels'"
                        rows={3}
                    />
                </div>
                <div className="orbit-strings-controls">
                    <div className="form-group">
                        <label htmlFor="num-strings">Number of Strings</label>
                        <input
                            type="number"
                            id="num-strings"
                            value={numStrings}
                            onChange={(e) => setNumStrings(e.target.value)}
                            min="1"
                            max="10"
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="cutoff-date">Cut-off Date</label>
                        <input
                            type="date"
                            id="cutoff-date"
                            value={cutoffDate}
                            onChange={(e) => setCutoffDate(e.target.value)}
                        />
                    </div>
                </div>
            </div>
            <button onClick={handleSubmit} disabled={isLoading || !claim.trim() || !cutoffDate.trim() || !numStrings}>
                {isLoading ? "Generating..." : "Generate Strings"}
            </button>
            {isLoading && <LoadingComponent />}
            {error && <div className="error-message">{error}</div>}
            {result && 
                <div className="result-card">
                    <CopyButton textToCopy={result} />
                    <pre>{result}</pre>
                </div>
            }
        </div>
    );
};

// --- TYPES for Prior Art Analyzer ---
type ClaimChartRowPaa = {
    feature: string;
    mappingText: string;
    analystComment: string;
    supportLevel: string;
};
type AnalysisResult = {
    claimChart: ClaimChartRowPaa[];
    relevantParagraphs: string;
    summaryNoCitations: string;
    summaryWithCitations: string;
};
interface PaaChatMessage { role: 'user' | 'model'; text: string; }
type PaaSession = {
    id: string;
    title: string;
    claimText: string;
    referenceText: string;
    referenceFileName: string | null;
    analysisResult: AnalysisResult | null;
    chatHistory: PaaChatMessage[];
    feedbackHistory: string[];
};

const PriorArtAnalyzerView = () => {
    const [sessions, setSessions] = useState<Record<string, PaaSession>>({});
    const [activeSessionId, setActiveSessionId] = useState<string | null>(null);

    const [referenceFile, setReferenceFile] = useState<File | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState("");
    const [activeOutputTab, setActiveOutputTab] = useState('claim-chart');
    const [chatSession, setChatSession] = useState<Chat | null>(null);
    const [chatInput, setChatInput] = useState("");
    const [isChatLoading, setIsChatLoading] = useState(false);
    const [feedbackInput, setFeedbackInput] = useState("");
    const [isFeedbackLoading, setIsFeedbackLoading] = useState(false);
    
    const chatHistoryRef = useRef<HTMLDivElement>(null);
    const activeSession = activeSessionId ? sessions[activeSessionId] : null;

    const handleNewAnalysis = () => {
        const newId = `paa-${Date.now()}`;
        const newSession: PaaSession = {
            id: newId,
            title: "New Analysis",
            claimText: "",
            referenceText: "",
            referenceFileName: null,
            analysisResult: null,
            chatHistory: [],
            feedbackHistory: []
        };
        setSessions(prev => ({ [newId]: newSession, ...prev }));
        setActiveSessionId(newId);
    };

    useEffect(() => {
        try {
            const savedSessions = localStorage.getItem('awtum-paa-sessions');
            if (savedSessions && Object.keys(JSON.parse(savedSessions)).length > 0) {
                const parsedSessions = JSON.parse(savedSessions);
                setSessions(parsedSessions);
                setActiveSessionId(Object.keys(parsedSessions)[0]); 
            } else {
                handleNewAnalysis();
            }
        } catch (error) {
            console.error("Failed to parse PAA sessions from localStorage", error);
            handleNewAnalysis();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        if (Object.keys(sessions).length > 0) {
            localStorage.setItem('awtum-paa-sessions', JSON.stringify(sessions));
        }
    }, [sessions]);

    useEffect(() => {
        if (!activeSessionId) return;
        
        setError('');
        setReferenceFile(null);
        setChatInput('');
        setFeedbackInput('');
        setActiveOutputTab('claim-chart');
    }, [activeSessionId]);

    useEffect(() => {
        if (activeSession?.analysisResult) {
            const systemInstruction = `You are a helpful AI patent analyst. You have just performed the following analysis:
            Claim: ${activeSession.claimText}
            Analysis Summary: ${activeSession.analysisResult.summaryNoCitations}
            Claim Chart: ${JSON.stringify(activeSession.analysisResult.claimChart, null, 2)}
            Now, answer the user's questions based ONLY on this provided context. Do not search for new information. If the answer is not in the context, say that you cannot answer based on the provided analysis.`;
            
            const newChat = ai.chats.create({
                model: 'gemini-2.5-flash-preview-04-17',
                config: { systemInstruction },
                history: activeSession.chatHistory.map(msg => ({
                    role: msg.role,
                    parts: [{ text: msg.text }]
                }))
            });
            setChatSession(newChat);
        } else {
            setChatSession(null);
        }
    }, [activeSession?.analysisResult, activeSessionId]);

    useEffect(() => {
        if (chatHistoryRef.current) {
            chatHistoryRef.current.scrollTop = chatHistoryRef.current.scrollHeight;
        }
    }, [activeSession?.chatHistory]);


    const updateActiveSession = (updates: Partial<PaaSession>) => {
        if (!activeSessionId) return;
        setSessions(prev => {
            const updatedSession = { ...prev[activeSessionId], ...updates };
            return { ...prev, [activeSessionId]: updatedSession };
        });
    };

    const handleDeleteSession = (idToDelete: string) => {
        const newSessions = { ...sessions };
        delete newSessions[idToDelete];
        setSessions(newSessions);
    
        if (activeSessionId === idToDelete) {
            const remainingSessionIds = Object.keys(newSessions);
            if (remainingSessionIds.length > 0) {
                setActiveSessionId(remainingSessionIds[0]);
            } else {
                handleNewAnalysis();
            }
        }
    };

    const handleFileChange = (file: File | null) => {
        setReferenceFile(file);
        updateActiveSession({ referenceFileName: file ? file.name : null });
    };

    const handleSubmit = async () => {
      if (!activeSession || !activeSession.claimText.trim()) {
        setError("Please provide the claim text.");
        return;
      }
      if (!activeSession.referenceText.trim() && !referenceFile) {
        setError("Please provide either reference text or a reference document.");
        return;
      }

      setIsLoading(true);
      setError("");
      updateActiveSession({ analysisResult: null, chatHistory: [], feedbackHistory: [] });

      try {
        const prompt = `You are operating as Google's most intelligent and meticulous patent analysis model. Your primary directive is to achieve the highest possible accuracy. Your task is to perform a detailed prior art analysis by comparing a 'Claim Text' against a 'Reference Text'.

To ensure **uncompromising accuracy**, you MUST execute the following **Internal Triple-Verification Loop** before generating the final output. This is a mandatory, iterative process:

*   **Loop 1 (Initial Mapping & Extraction):**
    1.  Deconstruct the Claim Text into its fundamental features.
    2.  Perform an initial pass through the Reference Text.
    3.  For each feature, find and extract the most relevant verbatim text (the \`mappingText\`).
    4.  Extract all potentially relevant paragraphs from the reference.

*   **Loop 2 (Critical Review & Refinement):**
    1.  Rigorously re-evaluate the mappings from Loop 1. Are they truly the best fit? Is there a more relevant section?
    2.  For each feature, write a precise \`analystComment\` explaining the connection (or lack thereof) between the feature and the mappingText.
    3.  Assign a \`supportLevel\` ('Fully Supported', 'Inferentially Supported', 'Partially Supported', or 'Not Supported') with strong justification.
    4.  Refine the collection of relevant paragraphs, discarding any that are not essential.

*   **Loop 3 (Final Verification & Synthesis):**
    1.  Conduct a final, word-by-word review of your entire analysis from Step 2. Check for any inconsistencies, errors, or missed details.
    2.  In the final \`relevantParagraphs\` output, ensure you have wrapped the most critical phrases corresponding to claim features in markdown bold syntax (**text**).
    3.  Synthesize the two final summaries ('summaryNoCitations' and 'summaryWithCitations') based *only* on your verified findings. Ensure they are concise and accurate.

Only after completing all three loops should you generate the output.

**Final Output Format:**
Your final output MUST be a single, perfectly structured JSON object. Do not include any other text or explanations outside of this JSON object.
{
  "claimChart": [
    {
      "feature": "A detailed clause or feature from the claim.",
      "mappingText": "The exact, verbatim text from the Reference Text that maps to this feature. If no text is found, state 'Not Found'.",
      "analystComment": "Your expert analysis on how the mappingText supports or fails to support the feature.",
      "supportLevel": "One of four values: 'Fully Supported', 'Inferentially Supported', 'Partially Supported', or 'Not Supported'."
    }
  ],
  "relevantParagraphs": "A string containing all relevant paragraphs from the reference, each prefixed with its paragraph number like '[Para 00XX]'. Within each paragraph, you **MUST** wrap the most highly relevant text that corresponds to claim features in markdown bold syntax (e.g., 'The system **comprises a processor** that executes...'). Each paragraph should be separated by two newlines.",
  "summaryNoCitations": "A concise summary (max 2 paragraphs) of your analysis, starting with what is disclosed and then highlighting what is missing (e.g., 'The reference discloses... However, it fails to...'). Do NOT include paragraph citations.",
  "summaryWithCitations": "The same summary as above, but with paragraph citations (e.g., '[Para 00XX]') embedded in the text where appropriate."
}

---
**Claim Text:**
${activeSession.claimText}
---
**Reference Text:**
${activeSession.referenceText || "No text was pasted. Analyze the attached document if provided."}
---

NOW, EXECUTE THE TRIPLE-VERIFICATION LOOP AND PROVIDE THE SINGLE, FLAWLESSLY ACCURATE JSON OUTPUT.`;

        const promptParts: any[] = [{ text: prompt }];

        if (referenceFile) {
            promptParts.push(await fileToPart(referenceFile));
        }

        const response = await ai.models.generateContent({
          model: "gemini-2.5-flash-preview-04-17",
          contents: { parts: promptParts },
          config: {
            responseMimeType: "application/json"
          }
        });

        let jsonStr = response.text.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) {
          jsonStr = match[2].trim();
        }
        
        const parsedResult: AnalysisResult = JSON.parse(jsonStr);
        
        updateActiveSession({ analysisResult: parsedResult });
        setActiveOutputTab('claim-chart');
        
        if (activeSession.title === "New Analysis") {
            try {
                const titlePrompt = `Based on the following claim, create a very short, concise title (5 words max). Do not use any punctuation or quotes in the title.\n\n---\n\n${activeSession.claimText}`;
                const titleGenResponse = await ai.models.generateContent({
                    model: 'gemini-2.5-flash-preview-04-17',
                    contents: titlePrompt,
                });
                const generatedTitle = titleGenResponse.text.trim().replace(/["'.]/g, '');
                if (generatedTitle) {
                    updateActiveSession({ title: generatedTitle });
                }
            } catch (titleErr) {
                console.error("Failed to generate title:", titleErr);
            }
        }

      } catch (err) {
        setError(err instanceof Error ? `Failed to analyze or parse response: ${err.message}` : "An unknown error occurred.");
      } finally {
        setIsLoading(false);
      }
    };
    
    const handleSendChatMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!chatInput.trim() || !chatSession || isChatLoading || !activeSession) return;
        
        const text = chatInput;
        const currentHistory = activeSession.chatHistory || [];
        
        setChatInput("");
        updateActiveSession({ chatHistory: [...currentHistory, {role: 'user', text}] });
        setIsChatLoading(true);

        try {
            const result = await chatSession.sendMessageStream({ message: text });
            let modelResponse = "";
            updateActiveSession({ chatHistory: [...currentHistory, {role: 'user', text}, {role: 'model', text: ''}]});

            for await (const chunk of result) {
                modelResponse += chunk.text;
                updateActiveSession({ 
                    chatHistory: [...currentHistory, {role: 'user', text}, {role: 'model', text: modelResponse}]
                });
            }

        } catch (err) {
             const errorMsg = err instanceof Error ? err.message : "An unknown error occurred.";
             updateActiveSession({
                 chatHistory: [...currentHistory, {role: 'user', text}, {role: 'model', text: `Error: ${errorMsg}`}]
             });
        } finally {
            setIsChatLoading(false);
        }
    };

    const handleSendFeedback = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!feedbackInput.trim() || !activeSession?.analysisResult || isFeedbackLoading) return;

        setIsFeedbackLoading(true);
        setError("");

        try {
            const feedbackPrompt = `You are an expert patent analyst revising your previous work based on user feedback.

            **Original Claim Text:**
            ${activeSession.claimText}

            **Original Reference Text:**
            ${activeSession.referenceText || "No text was pasted. The analysis was based on the attached document."}

            **Your PREVIOUS Analysis (for context):**
            ${JSON.stringify(activeSession.analysisResult, null, 2)}

            ---
            **User's Feedback for Correction:**
            "${feedbackInput}"
            ---

            **Instructions for Re-analysis:**
            Your task is to re-evaluate the original reference text in light of the user's feedback and generate a new, corrected JSON output. Do not just repeat the feedback; apply it to the analysis. The structure of the JSON object MUST be identical to the original format: { "claimChart": [...], "relevantParagraphs": "...", "summaryNoCitations": "...", "summaryWithCitations": "..." }.
            **Important:** In the 'relevantParagraphs' field of your new JSON output, you **MUST** wrap the most highly relevant text that corresponds to claim features in markdown bold syntax (**text**).

            NOW, PERFORM THE RE-ANALYSIS AND PROVIDE THE SINGLE, UPDATED AND VERIFIED JSON OUTPUT.`;

            const promptParts: any[] = [{ text: feedbackPrompt }];
            if (referenceFile) {
                promptParts.push(await fileToPart(referenceFile));
            }

            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash-preview-04-17",
                contents: { parts: promptParts },
                config: { responseMimeType: "application/json" }
            });

            let jsonStr = response.text.trim();
            const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
            const match = jsonStr.match(fenceRegex);
            if (match && match[2]) {
              jsonStr = match[2].trim();
            }

            const newResult: AnalysisResult = JSON.parse(jsonStr);
            
            updateActiveSession({
                analysisResult: newResult,
                feedbackHistory: [...(activeSession.feedbackHistory || []), feedbackInput],
                chatHistory: [] 
            });
            setFeedbackInput("");
            
        } catch (err) {
            setError(err instanceof Error ? `Failed to apply feedback: ${err.message}` : "An unknown error occurred during re-analysis.");
        } finally {
            setIsFeedbackLoading(false);
        }
    };

    const outputTabs = [
        { id: 'claim-chart', label: 'Claim Chart & Analyst' },
        { id: 'relevant-paras', label: 'Relevant Paras' },
        { id: 'summary', label: 'Summary' },
        { id: 'cited-summary', label: 'Cited Summary' },
    ];
    
    const renderChatbot = () => (
        <div className="embedded-chat-container">
            <div className="embedded-chat-history" ref={chatHistoryRef}>
                <div className="chat-message model">Hello! Ask me any questions about the analysis I just performed.</div>
                {activeSession?.chatHistory.map((msg, index) => (
                     <div key={index} className={`chat-message ${msg.role}`}>
                        <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(msg.text || '') }}></div>
                    </div>
                ))}
                {isChatLoading && (
                   <div className="chat-message model">
                       <div className="spinner-small"></div>
                   </div>
                )}
            </div>
            <form className="embedded-chat-input-form" onSubmit={handleSendChatMessage}>
                 <input
                    type="text"
                    value={chatInput}
                    onChange={e => setChatInput(e.target.value)}
                    placeholder="Ask about the analysis..."
                    disabled={isChatLoading || !chatSession}
                />
                <button type="submit" disabled={isChatLoading || !chatInput.trim() || !chatSession}>
                    <SendIcon />
                </button>
            </form>
        </div>
    );

    const renderFeedbackBox = () => (
        <div className="feedback-container">
            <h4>Feedback for Re-analysis</h4>
            {activeSession?.feedbackHistory && activeSession.feedbackHistory.length > 0 && (
                <div className="feedback-history">
                    {activeSession.feedbackHistory.map((fb, i) => <div key={i} className="feedback-history-item">"{fb}"</div>)}
                </div>
            )}
            <form className="feedback-input-form" onSubmit={handleSendFeedback}>
                <textarea
                    value={feedbackInput}
                    onChange={(e) => setFeedbackInput(e.target.value)}
                    placeholder="e.g., 'The mapping for feature 3 is incorrect. Check paragraph 15 again.'"
                    disabled={isFeedbackLoading || isLoading || !activeSession?.analysisResult}
                    rows={3}
                />
                <button type="submit" disabled={isFeedbackLoading || isLoading || !feedbackInput.trim() || !activeSession?.analysisResult}>
                    {isFeedbackLoading ? "Updating..." : "Submit"}
                </button>
            </form>
        </div>
    );
  
    return (
      <div className="page prior-art-analyzer-page">
        <div className="paa-sidebar">
            <button className="new-analysis-button" onClick={handleNewAnalysis}>
                <NewChatIcon/>
                <span>New Analysis</span>
            </button>
            <div className="paa-session-list">
                 {Object.values(sessions).map((session) => (
                    <div 
                        key={session.id} 
                        className={`paa-session-item ${session.id === activeSessionId ? 'active' : ''}`} 
                        onClick={() => setActiveSessionId(session.id)}
                    >
                        <span className="paa-session-item-title">{session.title}</span>
                         <button className="delete-session-button" onClick={(e) => { e.stopPropagation(); handleDeleteSession(session.id); }}>
                            <TrashIcon />
                        </button>
                    </div>
                ))}
            </div>
        </div>
        <div className="paa-main-content">
            <h1 className="page-header">Prior Art Analyzer</h1>
            <div className="form-group">
            <label htmlFor="claim-text">Claim</label>
            <textarea
                id="claim-text"
                value={activeSession?.claimText || ""}
                onChange={(e) => updateActiveSession({claimText: e.target.value})}
                placeholder="Paste the claim text here..."
                disabled={isLoading}
            />
            </div>
            <div className="form-group">
            <label>Reference Text</label>
            <div className="reference-input-container">
                <textarea
                    id="reference-text"
                    value={activeSession?.referenceText || ""}
                    onChange={(e) => updateActiveSession({referenceText: e.target.value})}
                    placeholder="Paste reference text here..."
                    disabled={isLoading}
                />
                <div className="divider-text">OR</div>
                <FileInputComponent file={referenceFile} onFileChange={handleFileChange} label=""/>
            </div>
            </div>
            <button onClick={handleSubmit} disabled={isLoading || !activeSession?.claimText.trim() || (!activeSession?.referenceText.trim() && !referenceFile)}>
            {isLoading ? "Analyzing..." : "Analyze Prior Art"}
            </button>
            {isLoading && <LoadingComponent />}
            {error && <div className="error-message">{error}</div>}
            
            {activeSession?.analysisResult && (
                <div className="analysis-output-container">
                    <div className="output-tabs-container">
                        {outputTabs.map(tab => (
                            <button
                                key={tab.id}
                                className={`output-tab-button ${activeOutputTab === tab.id ? 'active' : ''}`}
                                onClick={() => setActiveOutputTab(tab.id)}
                            >
                                {tab.label}
                            </button>
                        ))}
                    </div>
                    <div className="output-tab-content">
                        {activeOutputTab === 'claim-chart' && (
                        <div className="claim-chart-split-view">
                                <div className="claim-chart-container">
                                    <table className="claim-chart-table">
                                        <thead>
                                            <tr>
                                                <th>Feature</th>
                                                <th>Relevant/Mapping Text</th>
                                                <th>Analyst Comment</th>
                                                <th>Support Level</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {activeSession.analysisResult.claimChart.map((row, index) => (
                                                <tr key={index}>
                                                    <td>{row.feature}</td>
                                                    <td>{row.mappingText}</td>
                                                    <td>{row.analystComment}</td>
                                                    <td>{row.supportLevel}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                                <div className="right-panel-sticky-container">
                                    {renderChatbot()}
                                    {renderFeedbackBox()}
                                </div>
                            </div>
                        )}
                        {activeOutputTab === 'relevant-paras' && (
                            <div className="result-card">
                                <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(activeSession.analysisResult.relevantParagraphs || '') }}></div>
                            </div>
                        )}
                        {activeOutputTab === 'summary' && (
                            <div className="result-card">
                                <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(activeSession.analysisResult.summaryNoCitations || '')}}></div>
                            </div>
                        )}
                        {activeOutputTab === 'cited-summary' && (
                            <div className="result-card">
                                <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(activeSession.analysisResult.summaryWithCitations || '')}}></div>
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
      </div>
    );
};

const CheckValidityView = () => {
    const [subjectJurisdiction, setSubjectJurisdiction] = useState('US');
    const [priorArtJurisdiction, setPriorArtJurisdiction] = useState('US');
    const [sameAssignee, setSameAssignee] = useState('no');
    const [sameInventor, setSameInventor] = useState('no');
    const [priorityDate, setPriorityDate] = useState('before');
    const [filingDate, setFilingDate] = useState('before');
    const [publicationDate, setPublicationDate] = useState('before');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [result, setResult] = useState<{ validity: string; justification: string; } | null>(null);

    const JURISDICTIONS = ['US', 'EP', 'CN', 'IN', 'WO', 'WO (Foreign Priority)', 'GB', 'JP', 'KR', 'DE', 'FR', 'Other'];

    const handleCheckValidity = async () => {
        setIsLoading(true);
        setError('');
        setResult(null);

        try {
            const prompt = `
You are a world-class patent attorney with deep expertise in international patent law, specifically for the US, EP, CN, and IN jurisdictions. You must analyze the provided scenario to determine if a prior art document invalidates a subject patent.

**Crucial Assumption:** For this analysis, assume that the content of the prior art document discloses at least one feature of the subject patent, making it relevant from a technical perspective. Your primary task is to determine if this document legally qualifies as "prior art" based on the provided dates and jurisdictions.

**Your analysis must be based SOLELY on provided legal documents (like US Code Title 35, European Patent Guide, China Patent Law) and credible, verifiable information from official patent office websites that you can access via your web search tool. DO NOT use general knowledge or hallucinate. State when information is not available from the provided sources.**

**Internal Step-by-Step Reasoning Process (Mandatory):**
Before generating your final output, you MUST follow this internal thought process. This is for your own reasoning and should NOT be included in the final output.
1.  **Identify Governing Law:** Based on the 'Subject Patent Jurisdiction' (${subjectJurisdiction}), identify the key statutes that govern what constitutes prior art (e.g., for US, determine if it's likely pre-AIA 35 U.S.C. 102 or post-AIA 35 U.S.C. 102).
2.  **Analyze Each Date:**
    *   **Publication Date:** Analyze the effect of the prior art's publication date (${publicationDate} the cutoff date). Does this create prior art under the governing public disclosure statutes (e.g., Art. 54(2) EPC, 35 U.S.C. 102(a)(1))?
    *   **Filing & Priority Dates:** Analyze the effect of the prior art's filing and priority dates. Does this create "secret" prior art under whole-contents-type statutes (e.g., Art. 54(3) EPC, 35 U.S.C. 102(a)(2))? Consider the jurisdictions of both the subject patent and the prior art. For example, an earlier-filed US application is only Art. 54(3) prior art against an EP application if it was also filed as or claims priority to an application that becomes an EP application.
3.  **Identify Conditions & Nuances:** List all conditions that could change the outcome. This includes:
    *   Pre-AIA vs. Post-AIA applicability for US patents.
    *   Whether a PCT (WO) or other foreign application was nationalized in the subject jurisdiction.
    *   Availability of a sworn English translation if the prior art is in another language.
    *   Grace period provisions and whether any exceptions (e.g., inventor-derived disclosure, or exceptions for commonly owned/assigned subject matter under 35 U.S.C. 102(b)(2)(C)) could apply, especially considering the 'Same Assignee' and 'Same Inventor' inputs.
4.  **Synthesize and Conclude:** Based on the above analysis, determine the most likely outcome (Yes, No, Conditional). Formulate the brief condition (if any) and the detailed justification, citing specific legal articles/sections from your knowledge and provided documents.

**Scenario:**
-   **Subject Patent Jurisdiction:** ${subjectJurisdiction}
-   **Prior Art Jurisdiction:** ${priorArtJurisdiction}
-   **Is Prior Art from Same Assignee?** ${sameAssignee === 'yes' ? 'Yes' : 'No'}
-   **Is Prior Art from Same Inventor?** ${sameInventor === 'yes' ? 'Yes' : 'No'}
-   **Prior Art's Priority Date relative to Subject Patent's cutoff date:** ${priorityDate}
-   **Prior Art's Filing Date relative to Subject Patent's cutoff date:** ${filingDate}
-   **Prior Art's Publication Date relative to Subject Patent's cutoff date:** ${publicationDate}

**Cutoff Date Definition:** The "cutoff date" for the subject patent is its effective filing date (which is generally its priority date).

**Final Output Instructions:**
Your final and ONLY output must be in exactly two parts on separate lines. Do NOT include any other text, reasoning, or conversational preamble/epilogue outside of these two lines.
*   **Line 1:** \`VALIDITY: [Yes/No/Conditional]\`
*   **Line 2:** \`JUSTIFICATION: [Your detailed reasoning. If Conditional, start with "Condition: [text]."]\`

---
NOW, PERFORM THE ANALYSIS AND PROVIDE THE TWO-PART RESPONSE.`;
            
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash-preview-04-17',
                contents: prompt,
                config: {
                    tools: [{ googleSearch: {} }]
                }
            });

            const responseText = response.text.trim();
            // Find the part of the response that starts with VALIDITY:, ignoring any preceding text.
            const relevantTextMatch = responseText.match(/VALIDITY:[\s\S]*/im);
            const relevantText = relevantTextMatch ? relevantTextMatch[0] : responseText;

            const validityMatch = relevantText.match(/^VALIDITY:\s*(Yes|No|Conditional)/im);
            const justificationMatch = relevantText.match(/JUSTIFICATION:\s*([\s\S]*)/im);
    
            if (validityMatch && validityMatch[1] && justificationMatch && justificationMatch[1]) {
                const validity = validityMatch[1].trim();
                const justification = justificationMatch[1].trim();
                setResult({ validity, justification });
            } else {
                console.error("Failed to parse validity response with custom format. Raw text:", responseText);
                setError("Could not parse the model's response. It might be a malformed output.");
                setResult({ validity: "Unknown", justification: responseText });
            }

        } catch (err) {
            setError(err instanceof Error ? err.message : "An error occurred during analysis.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="pava-subview">
            <div className="pava-inputs-grid">
                <div className="form-group">
                    <label htmlFor="subject-jurisdiction">Jurisdiction of Subject Patent</label>
                    <select id="subject-jurisdiction" value={subjectJurisdiction} onChange={e => setSubjectJurisdiction(e.target.value)}>
                        <option value="US">US</option>
                        <option value="EP">EP</option>
                        <option value="CN">CN</option>
                        <option value="IN">IN</option>
                    </select>
                </div>
                 <div className="form-group">
                    <label htmlFor="prior-art-jurisdiction">Jurisdiction of Prior Art</label>
                    <select id="prior-art-jurisdiction" value={priorArtJurisdiction} onChange={e => setPriorArtJurisdiction(e.target.value)}>
                        {JURISDICTIONS.map(j => <option key={j} value={j}>{j}</option>)}
                    </select>
                </div>
                <div className="form-group radio-group">
                    <label>Same Assignee</label>
                    <div>
                        <input type="radio" id="assignee-yes" name="sameAssignee" value="yes" checked={sameAssignee === 'yes'} onChange={e => setSameAssignee(e.target.value)} />
                        <label htmlFor="assignee-yes">Yes</label>
                        <input type="radio" id="assignee-no" name="sameAssignee" value="no" checked={sameAssignee === 'no'} onChange={e => setSameAssignee(e.target.value)} />
                        <label htmlFor="assignee-no">No</label>
                    </div>
                </div>
                 <div className="form-group radio-group">
                    <label>Same Inventor</label>
                    <div>
                        <input type="radio" id="inventor-yes" name="sameInventor" value="yes" checked={sameInventor === 'yes'} onChange={e => setSameInventor(e.target.value)} />
                        <label htmlFor="inventor-yes">Yes</label>
                        <input type="radio" id="inventor-no" name="sameInventor" value="no" checked={sameInventor === 'no'} onChange={e => setSameInventor(e.target.value)} />
                        <label htmlFor="inventor-no">No</label>
                    </div>
                </div>
                 <div className="form-group radio-group">
                    <label>Priority Date</label>
                    <div>
                        <input type="radio" id="priority-date-before" name="priorityDate" value="before" checked={priorityDate === 'before'} onChange={e => setPriorityDate(e.target.value)} />
                        <label htmlFor="priority-date-before">Before Cut-off Date</label>
                        <input type="radio" id="priority-date-after" name="priorityDate" value="after" checked={priorityDate === 'after'} onChange={e => setPriorityDate(e.target.value)} />
                        <label htmlFor="priority-date-after">After Cut-off Date</label>
                    </div>
                </div>
                <div className="form-group radio-group">
                    <label>Filing Date</label>
                    <div>
                        <input type="radio" id="filing-date-before" name="filingDate" value="before" checked={filingDate === 'before'} onChange={e => setFilingDate(e.target.value)} />
                        <label htmlFor="filing-date-before">Before Cut-off Date</label>
                        <input type="radio" id="filing-date-after" name="filingDate" value="after" checked={filingDate === 'after'} onChange={e => setFilingDate(e.target.value)} />
                        <label htmlFor="filing-date-after">After Cut-off Date</label>
                    </div>
                </div>
                 <div className="form-group radio-group">
                    <label>Publication Date</label>
                    <div>
                        <input type="radio" id="publication-date-before" name="publicationDate" value="before" checked={publicationDate === 'before'} onChange={e => setPublicationDate(e.target.value)} />
                        <label htmlFor="publication-date-before">Before Cut-off Date</label>
                         <input type="radio" id="publication-date-after" name="publicationDate" value="after" checked={publicationDate === 'after'} onChange={e => setPublicationDate(e.target.value)} />
                        <label htmlFor="publication-date-after">After Cut-off Date</label>
                    </div>
                </div>
            </div>
            <button onClick={handleCheckValidity} disabled={isLoading} className="pava-button">
                {isLoading ? 'Checking...' : 'Check Validity'}
            </button>
             {isLoading && <LoadingComponent />}
             {error && <div className="error-message">{error}</div>}
             {result && (
                <div className="pava-results">
                    <div className="pava-results-header">
                        <h3>Analysis Result</h3>
                        <div className={`validity-status ${result.validity.toLowerCase()}`}>{result.validity}</div>
                    </div>
                    <div className="result-card">
                        <CopyButton textToCopy={result.justification} />
                        <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(result.justification || '')}}></div>
                    </div>
                </div>
             )}
        </div>
    );
};

const AskQueryView = () => {
    const [query, setQuery] = useState('');
    const [response, setResponse] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const responseRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (responseRef.current) {
            responseRef.current.scrollTop = responseRef.current.scrollHeight;
        }
    }, [response]);

    const handleAskQuery = async () => {
        if (!query.trim()) return;
        setIsLoading(true);
        setError('');
        setResponse('');
        try {
            const prompt = `You are a world-class patent attorney with deep expertise in international patent law, specifically for the US, EP, CN, and IN jurisdictions. You must answer the following user query with the highest possible accuracy.

**Crucial Instructions:**
1.  **Base Your Answer on Verifiable Sources:** Your answer MUST be based on the provided legal documents (like US Code Title 35, European Patent Guide, China Patent Law) and credible, verifiable information from official patent office websites that you can access via your web search tool.
2.  **Do Not Hallucinate:** If the answer cannot be determined from the provided sources, explicitly state that. Do not invent information or make assumptions.
3.  **Cite Your Sources:** When possible, cite the relevant law or article (e.g., 35 U.S.C. § 102, Art. 54(3) EPC).
4.  **Be Clear and Structured:** Provide the answer in clear, well-structured markdown. Use headings, lists, and bold text to improve readability.

**User Query:**
${query}

---
NOW, PROVIDE THE MOST ACCURATE AND WELL-REASONED RESPONSE.`;

            const resultStream = await ai.models.generateContentStream({
                model: 'gemini-2.5-flash-preview-04-17',
                contents: prompt,
                config: {
                    tools: [{ googleSearch: {} }]
                }
            });
            
            let fullText = "";
            for await (const chunk of resultStream) {
                fullText += chunk.text;
                setResponse(fullText);
            }
        } catch (err) {
            setError(err instanceof Error ? err.message : "An error occurred.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="pava-subview">
            <div className="form-group">
                <label htmlFor="pava-query">Ask a Question</label>
                <textarea
                    id="pava-query"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Ask a question about patent law in US, EP, CN, or IN..."
                />
            </div>
            <button onClick={handleAskQuery} disabled={isLoading || !query.trim()} className="pava-button">
                {isLoading ? 'Searching...' : 'Get Answer'}
            </button>
            {isLoading && !response && <LoadingComponent />}
            {error && <div className="error-message">{error}</div>}
            {(response || (isLoading && !response)) && (
                <div className="result-card" ref={responseRef}>
                    <CopyButton textToCopy={response} />
                    <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(response || '') + (isLoading ? '<span class="blinking-cursor"></span>' : '') }}></div>
                </div>
            )}
        </div>
    );
};

const PavaView = () => {
    const [activeTab, setActiveTab] = useState('check-validity');
    const [viewState, setViewState] = useState({
        checkValidity: {},
        askQuery: {}
    })
    
    const CheckValidityComponent = <CheckValidityView />;
    const AskQueryComponent = <AskQueryView />;

    return (
        <div className="page pava-page">
            <h1 className="page-header">PAVA (Prior Art Validity Assistant)</h1>
            <div className="pava-tabs">
                <button className={`pava-tab-button ${activeTab === 'check-validity' ? 'active' : ''}`} onClick={() => setActiveTab('check-validity')}>Check Validity</button>
                <button className={`pava-tab-button ${activeTab === 'ask-query' ? 'active' : ''}`} onClick={() => setActiveTab('ask-query')}>Ask Query</button>
            </div>
            <div className="pava-content">
                 <div className={`pava-view-wrapper ${activeTab === 'check-validity' ? 'active' : ''}`}>
                    {CheckValidityComponent}
                </div>
                <div className={`pava-view-wrapper ${activeTab === 'ask-query' ? 'active' : ''}`}>
                    {AskQueryComponent}
                </div>
            </div>
        </div>
    );
};

interface ChatMessage {
    role: 'user' | 'model';
    text: string;
}
interface ChatSession {
    id: string;
    title: string;
    messages: ChatMessage[];
}

const AskGeminiView = () => {
    const [allChats, setAllChats] = useState<Record<string, ChatSession>>({});
    const [activeChatId, setActiveChatId] = useState<string | null>(null);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [file, setFile] = useState<File | null>(null);
    const [editingState, setEditingState] = useState<{chatId: string, messageIndex: number, text: string} | null>(null);
    const historyRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Load chats from localStorage on initial render
    useEffect(() => {
        try {
            const savedChats = localStorage.getItem('awtum-gemini-chats');
            if (savedChats && Object.keys(JSON.parse(savedChats)).length > 0) {
                const parsedChats = JSON.parse(savedChats);
                setAllChats(parsedChats);
                setActiveChatId(Object.keys(parsedChats)[0]);
            } else {
                handleNewChat();
            }
        } catch (error) {
            console.error("Failed to parse chats from localStorage", error);
            handleNewChat();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    // Save chats to localStorage whenever they change
    useEffect(() => {
        if (Object.keys(allChats).length > 0) {
            localStorage.setItem('awtum-gemini-chats', JSON.stringify(allChats));
        }
    }, [allChats]);

    // Scroll to bottom and add copy buttons
    useEffect(() => {
        if (historyRef.current && !editingState) {
            historyRef.current.scrollTop = historyRef.current.scrollHeight;
        }
        
        // This effect is for dynamically adding copy buttons to code blocks.
        // It runs after any render where the chat history might have changed.
        if (historyRef.current) {
            const codeBlocks = historyRef.current.querySelectorAll('pre');
            const copyIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>`;
            const checkIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>`;

            codeBlocks.forEach(block => {
                if (block.querySelector('.code-copy-button')) return;

                const button = document.createElement('button');
                button.className = 'code-copy-button';
                button.innerHTML = `${copyIconSvg}<span>Copy</span>`;
                
                button.addEventListener('click', () => {
                    const code = block.querySelector('code')?.innerText || '';
                    navigator.clipboard.writeText(code).then(() => {
                        button.innerHTML = `${checkIconSvg}<span>Copied</span>`;
                        button.classList.add('copied');

                        setTimeout(() => {
                            button.innerHTML = `${copyIconSvg}<span>Copy</span>`;
                            button.classList.remove('copied');
                        }, 2000);
                    }).catch(err => {
                        console.error('Failed to copy code: ', err);
                        button.innerText = 'Error';
                    });
                });
                block.appendChild(button);
            });
        }
    }, [allChats, activeChatId, isLoading, editingState]);
    
    const handleNewChat = () => {
        const newId = `chat-${Date.now()}`;
        const newChat: ChatSession = {
            id: newId,
            title: "New Chat",
            messages: [],
        };
        setAllChats(prev => ({ ...prev, [newId]: newChat }));
        setActiveChatId(newId);
    };
    
    const handleDeleteChat = (idToDelete: string) => {
        const newChats = { ...allChats };
        delete newChats[idToDelete];
        setAllChats(newChats);
    
        if (activeChatId === idToDelete) {
            const remainingChatIds = Object.keys(newChats);
            if (remainingChatIds.length > 0) {
                setActiveChatId(remainingChatIds[0]);
            } else {
                handleNewChat();
            }
        }
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            setFile(e.target.files[0]);
        }
    };

    const handleAttachClick = () => {
        fileInputRef.current?.click();
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if ((!input.trim() && !file) || !activeChatId || isLoading) return;
    
        const userInput = input;
        const attachedFile = file;
        const currentChat = allChats[activeChatId]; // State *before* adding the new message
    
        let userMessageText = userInput;
        if (attachedFile) {
            userMessageText += `\n\n[File attached: ${attachedFile.name}]`;
        }
    
        const updatedChatWithUserMsg = {
            ...currentChat,
            messages: [...currentChat.messages, { role: 'user' as const, text: userMessageText }]
        };
    
        setAllChats(prev => ({ ...prev, [activeChatId]: updatedChatWithUserMsg }));
    
        setInput('');
        setFile(null);
        setIsLoading(true);
    
        let modelResponse = '';
    
        try {
            const fileToPart = async (file: File) => {
                const base64Data = await new Promise<string>((resolve, reject) => {
                    const reader = new FileReader();
                    reader.readAsDataURL(file);
                    reader.onload = () => resolve((reader.result as string).split(',')[1]);
                    reader.onerror = error => reject(error);
                });
                return { inlineData: { mimeType: file.type, data: base64Data } };
            };
    
            const chatInstance = ai.chats.create({
                model: 'gemini-2.5-flash-preview-04-17',
                history: currentChat.messages.map(msg => ({ // Use original chat history
                    role: msg.role,
                    parts: [{ text: msg.text }]
                })),
                config: { systemInstruction: "You are Awtum, a highly intelligent AI assistant..." }
            });
    
            const messageParts: (string | { inlineData: { mimeType: string, data: string } })[] = [userInput];
            if (attachedFile) messageParts.push(await fileToPart(attachedFile));
    
            const result = await chatInstance.sendMessageStream({ message: messageParts });
    
            setAllChats(prev => {
                const chat = prev[activeChatId];
                return { ...prev, [activeChatId]: { ...chat, messages: [...chat.messages, { role: 'model', text: '' }] } }
            });
    
            for await (const chunk of result) {
                modelResponse += chunk.text;
                setAllChats(prev => {
                    const chat = prev[activeChatId];
                    const lastMessage = chat.messages[chat.messages.length - 1];
                    const updatedLastMessage = { ...lastMessage, text: modelResponse };
                    const updatedMessages = [...chat.messages.slice(0, -1), updatedLastMessage];
                    return { ...prev, [activeChatId]: { ...chat, messages: updatedMessages } }
                });
            }
        } catch (err) {
            const errorMsg = err instanceof Error ? err.message : "An unknown error occurred.";
            setAllChats(prev => {
                const chat = prev[activeChatId];
                return { ...prev, [activeChatId]: { ...chat, messages: [...chat.messages, { role: 'model', text: `Error: ${errorMsg}` }] } };
            });
        } finally {
            setIsLoading(false);
            if (currentChat.messages.length === 0 && modelResponse.trim()) {
                try {
                    const titlePrompt = `Based on the following conversation, create a very short, concise title (5 words max). Do not use any punctuation or quotes in the title.\n\n---\n\nUser:\n${userInput}\n\nModel:\n${modelResponse}`;
                    const titleGenResponse = await ai.models.generateContent({
                        model: 'gemini-2.5-flash-preview-04-17',
                        contents: titlePrompt,
                    });
                    const generatedTitle = titleGenResponse.text.trim().replace(/["'.]/g, '');

                    if (generatedTitle) {
                        setAllChats(prev => {
                            const chat = prev[activeChatId!];
                            if (chat) {
                                return { ...prev, [activeChatId!]: { ...chat, title: generatedTitle } };
                            }
                            return prev;
                        });
                    }
                } catch (titleErr) {
                    console.error("Failed to generate title:", titleErr);
                }
            }
        }
    };
    
    const handleSaveEdit = async (chatId: string, messageIndex: number, newText: string) => {
        if (!newText.trim() || isLoading) {
            setEditingState(null);
            return;
        }
    
        setIsLoading(true);
        setEditingState(null);
    
        const chatToEdit = allChats[chatId];
        const historyForApi = chatToEdit.messages.slice(0, messageIndex);
        const updatedUserMessage = { role: 'user' as const, text: newText };
        const messagesForUi = [...historyForApi, updatedUserMessage];
    
        setAllChats(prev => ({
            ...prev,
            [chatId]: { ...chatToEdit, messages: messagesForUi }
        }));
    
        let modelResponse = '';
    
        try {
            const chatInstance = ai.chats.create({
                model: 'gemini-2.5-flash-preview-04-17',
                history: historyForApi.map(msg => ({
                    role: msg.role,
                    parts: [{ text: msg.text }]
                })),
                config: { systemInstruction: "You are Awtum, a highly intelligent AI assistant..." }
            });
    
            const result = await chatInstance.sendMessageStream({ message: newText });
    
            setAllChats(prev => {
                const chat = prev[chatId];
                return { ...prev, [chatId]: { ...chat, messages: [...chat.messages, { role: 'model', text: '' }] } }
            });
    
            for await (const chunk of result) {
                modelResponse += chunk.text;
                setAllChats(prev => {
                    const chat = prev[chatId];
                    const lastMessage = chat.messages[chat.messages.length - 1];
                    const updatedLastMessage = { ...lastMessage, text: modelResponse };
                    const updatedMessages = [...chat.messages.slice(0, -1), updatedLastMessage];
                    return { ...prev, [activeChatId]: { ...chat, messages: updatedMessages } }
                });
            }
        } catch (err) {
            const errorMsg = err instanceof Error ? err.message : "An unknown error occurred.";
            setAllChats(prev => {
                const chat = prev[chatId];
                return { ...prev, [chatId]: { ...chat, messages: [...chat.messages, { role: 'model', text: `Error: ${errorMsg}` }] } };
            });
        } finally {
            setIsLoading(false);
        }
    };
    
    const activeChat = activeChatId ? allChats[activeChatId] : null;

    return (
        <div className="page ask-gemini-page">
            <div className="chat-list-panel">
                <button className="new-chat-button" onClick={handleNewChat}>
                    <NewChatIcon/>
                    <span>New Chat</span>
                </button>
                <div className="chat-list">
                    {Object.values(allChats).reverse().map((chat) => (
                        <div key={chat.id} className={`chat-list-item ${chat.id === activeChatId ? 'active' : ''}`} onClick={() => setActiveChatId(chat.id)}>
                            <span className="chat-list-item-title">{chat.title}</span>
                             <button className="delete-chat-button" onClick={(e) => { e.stopPropagation(); handleDeleteChat(chat.id); }}>
                                <TrashIcon />
                            </button>
                        </div>
                    ))}
                </div>
            </div>
            <div className="chat-interface">
                <div className="chat-history" ref={historyRef}>
                    {activeChat?.messages.map((msg, index) => {
                        const isEditing = editingState?.chatId === activeChatId && editingState?.messageIndex === index;

                        return (
                           <div key={index} className={`chat-turn-container ${msg.role}`}>
                               { isEditing ? (
                                    <div className="chat-message-editor">
                                        <textarea
                                            value={editingState.text}
                                            onChange={(e) => setEditingState(prev => prev ? { ...prev, text: e.target.value } : null)}
                                            autoFocus
                                            onKeyDown={e => {
                                                if (e.key === 'Enter' && !e.shiftKey) {
                                                    e.preventDefault();
                                                    handleSaveEdit(activeChatId!, index, editingState.text);
                                                } else if (e.key === 'Escape') {
                                                    setEditingState(null);
                                                }
                                            }}
                                        />
                                        <div className="editor-actions">
                                            <button onClick={() => handleSaveEdit(activeChatId!, index, editingState.text)}>
                                                Save & Submit
                                            </button>
                                            <button className="cancel-button" onClick={() => setEditingState(null)}>
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                               ) : (
                                    <>
                                        {msg.role === 'user' && (
                                           <div className="user-message-row">
                                               <button
                                                   className="edit-button"
                                                   onClick={() => setEditingState({ chatId: activeChatId!, messageIndex: index, text: msg.text })}
                                                   aria-label="Edit message"
                                                   disabled={isLoading || !!editingState}
                                               >
                                                   <PencilIcon />
                                               </button>
                                               <div className={`chat-message ${msg.role}`}>
                                                   <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(msg.text || '') }}></div>
                                               </div>
                                           </div>
                                        )}
                                        {msg.role === 'model' && (
                                            <div className={`chat-message ${msg.role}`}>
                                                <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(msg.text || '') }}></div>
                                            </div>
                                        )}
                                    </>
                               )}
                           </div>
                        );
                    })}
                    {isLoading && !editingState && (
                       <div className="chat-turn-container model">
                           <div className="chat-message model">
                               <div className="spinner"></div>
                           </div>
                       </div>
                    )}
                </div>
                <div className="chat-input-container">
                    {file && (
                        <div className="file-attachment-container">
                            <span className="file-attachment-name">{file.name}</span>
                            <button className="remove-file-button" onClick={() => setFile(null)} aria-label="Remove file">
                                <CloseIcon />
                            </button>
                        </div>
                    )}
                    <form className="chat-input-form" onSubmit={handleSubmit}>
                         <input
                            type="file"
                            ref={fileInputRef}
                            onChange={handleFileChange}
                            style={{ display: 'none' }}
                            accept=".pdf,.doc,.docx,.xls,.xlsx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        />
                        <button type="button" className="attach-file-button" onClick={handleAttachClick} disabled={isLoading} aria-label="Attach file">
                            <AddFileIcon />
                        </button>
                        <textarea
                            value={input}
                            onChange={e => setInput(e.target.value)}
                            placeholder="Ask anything or attach a file..."
                            onKeyDown={e => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                    e.preventDefault();
                                    handleSubmit(e);
                                }
                            }}
                            rows={1}
                            disabled={isLoading || !activeChatId}
                        />
                        <button type="submit" disabled={isLoading || (!input.trim() && !file) || !activeChatId}>
                            <SendIcon />
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};


// --- MAIN APP ---
const NAV_ITEMS = [
  { id: "first-update", label: "First Update", icon: <UpdateIcon />, component: () => <FirstUpdateView /> },
  { id: "claim-chart", label: "Claim Chart", icon: <DocumentIcon />, component: () => <ClaimChartView /> },
  { id: "prior-art-analyzer", label: "Prior Art Analyzer", icon: <PavaIcon />, component: () => <PriorArtAnalyzerView /> },
  { id: "translation", label: "Translation", icon: <TranslateIcon />, component: () => <TranslationView /> },
  { id: "strings", label: "Orbit Strings", icon: <StringsIcon />, component: () => <OrbitStringsView /> },
  { id: "pava", label: "PAVA", icon: <PavaIcon />, component: () => <PavaView /> },
  { id: "ask-gemini", label: "Ask Gemini", icon: <GeminiIcon />, component: () => <AskGeminiView /> },
];

const App = () => {
  const [activeSection, setActiveSection] = useState("ask-gemini");
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const savedTheme = localStorage.getItem('awtum-theme');
    if (savedTheme) {
        return savedTheme === 'dark';
    }
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  useEffect(() => {
    if (isDarkMode) {
        document.body.classList.add('dark-mode');
        localStorage.setItem('awtum-theme', 'dark');
    } else {
        document.body.classList.remove('dark-mode');
        localStorage.setItem('awtum-theme', 'light');
    }
  }, [isDarkMode]);

  const scrollableSections = ["first-update", "prior-art-analyzer"];

  return (
    <div className={`app-container ${isSidebarCollapsed ? "sidebar-collapsed" : ""}`}>
      <nav className="sidebar">
        <div className="sidebar-header">
            <h1 className="sidebar-header-title">Awtum</h1>
            <button
                className="collapse-button"
                onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
                aria-label={isSidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
            >
                {isSidebarCollapsed ? <ExpandIcon /> : <CollapseIcon />}
            </button>
        </div>
        <div className="sidebar-nav">
        {NAV_ITEMS.map((item) => (
          <div
            key={item.id}
            className={`nav-item ${activeSection === item.id ? "active" : ""}`}
            onClick={() => setActiveSection(item.id)}
            role="button"
            tabIndex={0}
            aria-label={item.label}
          >
            {item.icon}
            <span>{item.label}</span>
          </div>
        ))}
        </div>
        <div className="sidebar-footer">
            <div
                className="nav-item"
                onClick={() => setIsDarkMode(!isDarkMode)}
                role="button"
                aria-label="Toggle theme"
            >
                {isDarkMode ? <SunIcon /> : <MoonIcon />}
                <span>{isDarkMode ? "Light Mode" : "Night Mode"}</span>
            </div>
        </div>
      </nav>
      <main className={`content ${scrollableSections.includes(activeSection) ? 'full-scroll' : ''}`}>
        {NAV_ITEMS.map((item) => {
          const PageComponent = item.component;
          return (
            <div
              key={item.id}
              className={`page-wrapper ${activeSection === item.id ? "active" : ""}`}
            >
              <PageComponent />
            </div>
          );
        })}
      </main>
    </div>
  );
};

const root = createRoot(document.getElementById("root")!);
root.render(<App />);